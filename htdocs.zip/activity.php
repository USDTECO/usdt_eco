<?php
session_start();
require_once 'db.php';

// Traitement de la suppression
if (isset($_GET['delete_id'])) {
    $stmt = $pdo->prepare("DELETE FROM publications WHERE id = ? AND user_id = ?");
    $stmt->execute([$_GET['delete_id'], $_SESSION['user_id']]);
    header("Location: activity.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    
    <style>
        html, body { top: 0 !important; position: relative !important; }
        .goog-te-banner-frame.skiptranslate, .goog-te-banner-frame, .goog-te-balloon-frame, 
        #goog-gt-tt, .goog-te-gadget-icon, .skiptranslate iframe { display: none !important; visibility: hidden !important; }
        #google_translate_element { display: none !important; }
    </style>

    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family: sans-serif; }
        body { background: url('image/background.jpg') no-repeat center center fixed; background-size: cover; display: flex; justify-content: center; min-height: 100vh; }
        body::before { content: ""; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: inherit; filter: blur(8px); z-index: -1; }
        
        .mobile { width: 390px; min-height: 100vh; background: rgba(244, 247, 249, 0.95); padding: 20px; padding-bottom: 90px; box-shadow: 0 0 20px rgba(0,0,0,0.2); position: relative; }
        
        .header { margin-bottom: 20px; }
        .logo { max-width: 150px; display: block; margin-bottom: 10px; }
        h2 { font-size: 1.2rem; color: #333; margin: 0; }

        .pub-item { background: #fff; border-radius: 15px; padding: 15px; margin-bottom: 15px; box-shadow: 0 2px 8px rgba(0,0,0,0.05); position: relative; }
        .btn-delete { position: absolute; top: 15px; right: 15px; color: #ff5252; cursor: pointer; font-size: 1.1rem; }
        
        .flex-container { display: flex; gap: 15px; margin-bottom: 15px; }
        .img-pub { width: 80px; height: 80px; object-fit: cover; border-radius: 10px; }
        .title { font-weight: bold; font-size: 0.95rem; display: block; }
        .desc { font-size: 0.8rem; color: #666; margin-top: 5px; }
        
        .grid-info { display: grid; grid-template-columns: 1fr 1fr; gap: 10px; margin: 15px 0; text-align: center; }
        .value { font-weight: bold; color: #1a237e; font-size: 0.95rem; }
        .btn-accept { width: 100%; padding: 12px; background: #00c853; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }

        .empty-state { text-align: center; margin-top: 80px; color: #888; }
        .empty-state i { font-size: 60px; color: #cbd5e0; margin-bottom: 15px; }

        .modal-overlay { display: none; position: fixed; top:0; left:0; width:100%; height:100%; background:rgba(0,0,0,0.6); z-index:999; justify-content:center; align-items:center; backdrop-filter:blur(4px); }
        .modal { background:white; width: 90%; max-width: 360px; padding: 40px 30px; border-radius: 30px; text-align:center; box-shadow: 0 20px 40px rgba(0,0,0,0.25); }
        .large-icon { font-size: 100px !important; margin-bottom: 25px; display: block; line-height: 1; }
        #modal-title { font-size: 1.3rem; color: #222; margin-bottom: 15px; font-weight: 800; }
        #modal-msg { font-size: 0.95rem; color: #555; margin-bottom: 35px; line-height: 1.4; }
        .modal-btn { display:flex; gap:12px; }
        .modal-btn button, .modal-btn a { flex:1; padding: 16px; border:none; border-radius: 16px; cursor:pointer; font-weight:700; font-size: 1rem; text-decoration:none; display:flex; justify-content:center; align-items:center; }

        .bottom-nav { position:fixed; bottom:0; width:390px; background:white; display:flex; justify-content:space-evenly; padding:12px 0; border-top:1px solid #eee; z-index:100; box-shadow: 0 -2px 10px rgba(0,0,0,0.05); }
        .nav-item { text-align:center; color:#777; font-size:10px; display:flex; flex-direction:column; align-items:center; gap:5px; cursor:pointer; }
        .nav-item i { font-size: 20px; }
        .nav-item.active { color:#1a237e; font-weight: bold; }
        a { text-decoration: none; }
    </style>
</head>
<body>
<div class="mobile">
    <div class="header">
        <img src="image/logo.png" alt="Logo" class="logo">
        <h2>Mes activités</h2>
    </div>

    <div id="pub-container"></div>
</div>

<div id="modal" class="modal-overlay">
    <div class="modal">
        <div id="modal-icon"></div>
        <h3 id="modal-title"></h3>
        <p id="modal-msg"></p>
        <div class="modal-btn" id="modal-actions"></div>
    </div>
</div>

<nav class="bottom-nav">
    <a href="index.php" class="nav-item"><i class="fa-solid fa-user"></i>Compte</a>
    <a href="activity.php" class="nav-item active"><i class="fa-solid fa-chart-line"></i>Activité</a>
    <a href="assistance.php"><div class="nav-item"><i class="fa-solid fa-headset"></i>Assistance</div></a>
    <a href="info.php"><div class="nav-item"><i class="fa-solid fa-circle-info"></i>À propos</div></a>
</nav>

<script>
function showModal(type, id, solde = 0, profit = 0, dispo = 1) {
    const modal = document.getElementById('modal');
    const title = document.getElementById('modal-title');
    const msg = document.getElementById('modal-msg');
    const icon = document.getElementById('modal-icon');
    const actions = document.getElementById('modal-actions');
    
    icon.className = 'large-icon';
    modal.style.display = 'flex';
    actions.innerHTML = '';
    
    if (dispo == 0) {
        icon.innerHTML = '<i class="fa-solid fa-circle-exclamation" style="color:#fbc02d;"></i>';
        title.innerText = "Offre indisponible";
        msg.innerText = "Cette offre n'est plus disponible. Souhaitez-vous la supprimer ?";
        actions.innerHTML = `<button onclick="closeModal()" style="background:#eee; color:#333;">Annuler</button>
                             <button onclick="window.location.href='?delete_id=${id}'" style="background:#ff5252; color:white;">Supprimer</button>`;
    } 
    else if(type === 'delete') {
        icon.innerHTML = '<i class="fa-solid fa-trash-can" style="color:#ff5252;"></i>';
        title.innerText = "Suppression";
        msg.innerText = "Souhaitez-vous vraiment supprimer l'offre ?";
        actions.innerHTML = `<button onclick="closeModal()" style="background:#eee; color:#333;">Annuler</button>
                             <button onclick="window.location.href='?delete_id=${id}'" style="background:#ff5252; color:white;">Supprimer</button>`;
    } 
    else if(type === 'insufficient') {
        icon.innerHTML = '<i class="fa-solid fa-circle-xmark" style="color:#ff3b30;"></i>';
        title.innerText = "Solde insuffisant";
        msg.innerText = "Votre solde est insuffisant pour effectuer cette opération.";
        actions.innerHTML = `<button onclick="closeModal()" style="background:#333; color:white; width:100%;">ANNULER</button>`;
    } 
    else {
        icon.innerHTML = '<i class="fa-solid fa-circle-check" style="color:#2ecc71;"></i>';
        title.innerText = "Confirmation";
        msg.innerText = "Souhaiez-vous libérer $" + solde + " pour obtenir $" + profit + " de commission ?";
        actions.innerHTML = `<button onclick="closeModal()" style="background:#eee; color:#333;">Annuler</button>
                             <button onclick="window.location.href='traiter_acceptation.php?id=${id}'" style="background:#1a237e; color:white;">Confirmer</button>`;
    }
}
function closeModal() { document.getElementById('modal').style.display = 'none'; }

// Chargement stabilisé pour éviter le clignotement de la traduction
function chargerPublications() {
    fetch('get_publications.php')
        .then(response => response.text())
        .then(data => {
            const container = document.getElementById('pub-container');
            // On ne met à jour que si le contenu est différent pour ne pas perturber Google
            if (container.innerHTML.trim() !== data.trim()) {
                container.innerHTML = data;
            }
        });
}
setInterval(chargerPublications, 10000);
chargerPublications();

const urlParams = new URLSearchParams(window.location.search);
if (urlParams.get('error') === 'insufficient') {
    showModal('insufficient');
    window.history.replaceState({}, document.title, "activity.php");
}
</script>

<?php include 'traduction_script.php'; ?>

</body>
</html>