<?php
session_start();
require_once 'db.php';

// SÉCURITÉ : Vérification robuste du rôle stocké en session
if (!isset($_SESSION['user_id']) || !isset($_SESSION['role']) || strtolower(trim($_SESSION['role'])) !== 'admin') {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Interface Administrateur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: sans-serif; background: #f0f2f5; padding: 20px; }
        .container { max-width: 600px; margin: auto; }
        h2 { text-align: center; color: #1a237e; margin-bottom: 30px; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .card { background: white; padding: 25px; border-radius: 15px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); cursor: pointer; transition: 0.3s; }
        .card:hover { transform: translateY(-5px); background: #f8f9fa; }
        .card i { font-size: 2.5rem; color: #1a237e; margin-bottom: 15px; }
        .card p { font-weight: bold; color: #333; }
        a { text-decoration: none; }
    </style>
</head>
<body>

<div class="container">
    <h2>Panneau d'Administration</h2>
    
    <div class="grid">
        <a href="admin_historique.php" class="card">
            <i class="fa-solid fa-clock-rotate-left"></i>
            <p>Historique</p>
        </a>
        <a href="admin_users.php" class="card">
            <i class="fa-solid fa-users"></i>
            <p>Utilisateurs</p>
        </a>
        <a href="voir_kyc.php" class="card">
            <i class="fa-solid fa-id-card"></i>
            <p>Vérifier KYC</p>
        </a>
        <a href="admin_publier.php" class="card">
            <i class="fa-solid fa-bullhorn"></i>
            <p>Publier Offre</p>
        </a>
        <a href="generer_code.php" class="card">
            <i class="fa-solid fa-barcode"></i>
            <p>Générer Codes</p>
        </a>
        <a href="solder.php" class="card">
            <i class="fa-solid fa-wallet"></i>
            <p>Solder Comptes</p>
        </a>
        <a href="index.php" class="card" style="background: #ffebee;">
            <i class="fa-solid fa-arrow-left" style="color: #c62828;"></i>
            <p>Retour Accueil</p>
        </a>
    </div>
</div>

</body>
</html>