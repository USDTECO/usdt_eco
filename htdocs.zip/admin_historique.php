<?php
session_start();
require_once 'db.php';

// Action de mise à jour (Ajax)
if (isset($_POST['update_trans'])) {
    $stmt = $pdo->prepare("UPDATE transactions SET montant = ?, date = ? WHERE id = ?");
    $stmt->execute([$_POST['montant'], $_POST['date'], $_POST['id']]);
    echo "Succès";
    exit();
}

// Action de suppression
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM transactions WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: admin_historique.php");
}

// Liste des utilisateurs
$users = $pdo->query("SELECT id, nom_prenom FROM utilisateurs")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Gestion Historique</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #f4f7f6; }
        .container { display: flex; gap: 20px; }
        .side { background: white; padding: 20px; border-radius: 10px; width: 300px; }
        .main { background: white; padding: 20px; border-radius: 10px; flex-grow: 1; }
        .user-link { display: block; padding: 10px; border-bottom: 1px solid #eee; cursor: pointer; color: #1a237e; font-weight: bold; }
        input { padding: 5px; width: 100px; }
    </style>
</head>
<body>

<div class="container">
    <div class="side">
        <h3>Utilisateurs</h3>
        <?php foreach ($users as $u): ?>
            <div class="user-link" onclick="loadUser(<?= $u['id'] ?>)"><?= $u['nom_prenom'] ?></div>
        <?php endforeach; ?>
    </div>
    
    <div class="main" id="main-content">
        <h3>Sélectionnez un utilisateur pour voir son historique</h3>
    </div>
</div>

<script>
function loadUser(userId) {
    // Appel pour charger l'historique de l'utilisateur
    fetch('get_user_history.php?user_id=' + userId)
        .then(res => res.text())
        .then(data => document.getElementById('main-content').innerHTML = data);
}

function saveTrans(id) {
    let m = document.getElementById('m_'+id).value;
    let d = document.getElementById('d_'+id).value;
    let fd = new FormData();
    fd.append('update_trans', '1');
    fd.append('id', id);
    fd.append('montant', m);
    fd.append('date', d);
    fetch('', {method:'POST', body:fd}).then(() => alert('Modifié !'));
}
</script>
</body>
</html>
