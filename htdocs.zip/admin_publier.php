<?php
session_start();
require_once 'db.php';

// 1. ACTION AJAX : Chargement des publications
if (isset($_GET['action']) && $_GET['action'] == 'load_pubs') {
    $uid = $_GET['uid'];
    $stmt = $pdo->prepare("SELECT * FROM publications WHERE user_id = ? ORDER BY id DESC");
    $stmt->execute([$uid]);
    $pubs = $stmt->fetchAll();
    
    foreach($pubs as $p) {
        $is_active = $p['disponible'];
        $badge_class = $is_active ? 'badge-on' : 'badge-off';
        $badge_text = $is_active ? 'ACTIF' : 'DÉSACTIVÉ';
        $card_style = $is_active ? '' : 'opacity: 0.6; filter: grayscale(1);';
        
        echo "<div class='pub-item' style='$card_style'>
                <div style='flex-grow: 1;'>
                    <div style='display: flex; justify-content: space-between; align-items: center;'>
                        <strong>{$p['titre']}</strong>
                        <span class='$badge_class'>$badge_text</span>
                    </div>
                    <small style='color: #666;'>{$p['description']}</small><br>
                    <small><b>Solde:</b> {$p['solde']} | <b>Profit:</b> {$p['profit']}</small>
                </div>
                <div style='margin-left: 15px;'>
                    <button onclick='managePub({$p['id']}, \"toggle\")' title='Activer/Désactiver'><i class='fa-solid fa-power-off'></i></button>
                    <button onclick='managePub({$p['id']}, \"delete\")' style='color:red;' title='Supprimer'><i class='fa-solid fa-trash'></i></button>
                </div>
              </div>";
    }
    exit();
}

// 2. ACTION AJAX : Suppression ou Activation
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['cmd'])) {
    if ($_POST['cmd'] == 'delete') $pdo->prepare("DELETE FROM publications WHERE id = ?")->execute([$_POST['id']]);
    if ($_POST['cmd'] == 'toggle') $pdo->prepare("UPDATE publications SET disponible = NOT disponible WHERE id = ?")->execute([$_POST['id']]);
    exit();
}

// 3. ACTION POST : Publication
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['publier'])) {
    if (!is_dir('uploads')) mkdir('uploads', 0777, true);
    $path = 'uploads/' . time() . '_' . basename($_FILES['image']['name']);
    move_uploaded_file($_FILES['image']['tmp_name'], $path);
    $pdo->prepare("INSERT INTO publications (user_id, titre, description, solde, profit, image_url, disponible) VALUES (?,?,?,?,?,?,1)")
        ->execute([$_POST['user_id'], $_POST['titre'], $_POST['description'], $_POST['solde'], $_POST['profit'], $path]);
}

$users = $pdo->query("SELECT id, nom_prenom FROM utilisateurs")->fetchAll();
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { background: #f4f7f9; padding: 20px; font-family: sans-serif; }
        .card { max-width: 400px; margin: auto; background: white; padding: 20px; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); margin-bottom: 20px; }
        .pub-item { background: white; padding: 15px; margin-bottom: 10px; border-radius: 10px; display: flex; justify-content: space-between; align-items: center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        input, select, textarea, button { width: 100%; padding: 12px; margin: 8px 0; border-radius: 10px; border: 1px solid #ddd; box-sizing: border-box; }
        button { background: #1a237e; color: white; border: none; cursor: pointer; }
        .badge-on { background: #e8f5e9; color: #2e7d32; padding: 4px 8px; border-radius: 5px; font-size: 10px; font-weight: bold; border: 1px solid #2e7d32; }
        .badge-off { background: #ffebee; color: #c62828; padding: 4px 8px; border-radius: 5px; font-size: 10px; font-weight: bold; border: 1px solid #c62828; }
    </style>
</head>
<body>
    <div class="card">
        <h2>Nouvelle Publication</h2>
        <form method="POST" enctype="multipart/form-data">
            <select name="user_id" required><option value="">Choisir utilisateur</option>
                <?php foreach($users as $u): ?><option value="<?=$u['id']?>"><?=$u['nom_prenom']?></option><?php endforeach; ?></select>
            <input type="text" name="titre" placeholder="Titre" required>
            <textarea name="description" placeholder="Description" rows="3" required></textarea>
            <input type="number" step="0.01" name="solde" id="solde" placeholder="Solde" oninput="document.getElementById('profit').value=(this.value*0.25).toFixed(2)">
            <input type="number" step="0.01" name="profit" id="profit" placeholder="Profit" readonly>
            <input type="file" name="image" required>
            <button type="submit" name="publier">PUBLIER</button>
        </form>
    </div>

    <div class="card">
        <select id="user_select" onchange="loadPubs(this.value)">
            <option value="">Sélectionner un utilisateur pour gérer</option>
            <?php foreach($users as $u): ?><option value="<?=$u['id']?>"><?=$u['nom_prenom']?></option><?php endforeach; ?></select>
        <div id="pub-list" style="margin-top:15px;"></div>
    </div>

    <script>
    function loadPubs(uid) {
        if(!uid) return;
        fetch('?action=load_pubs&uid=' + uid).then(r => r.text()).then(h => document.getElementById('pub-list').innerHTML = h);
    }
    function managePub(id, cmd) {
        let fd = new FormData(); fd.append('id', id); fd.append('cmd', cmd);
        fetch('', {method: 'POST', body: fd}).then(() => loadPubs(document.getElementById('user_select').value));
    }
    </script>
</body>
</html>