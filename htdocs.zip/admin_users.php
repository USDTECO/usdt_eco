<?php
require_once 'db.php';
session_start();

// SÉCURITÉ : Vérification du rôle admin
if (!isset($_SESSION['role']) || strtolower(trim($_SESSION['role'])) !== 'admin') {
    header("Location: index.php");
    exit();
}

// --- LOGIQUES D'ACTION ---
// 1. Suppression
if (isset($_GET['delete'])) {
    $pdo->prepare("DELETE FROM utilisateurs WHERE id = ?")->execute([$_GET['delete']]);
    header("Location: admin_users.php"); exit();
}

// 2. Mise à jour de rôle
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_role'])) {
    $pdo->prepare("UPDATE utilisateurs SET role = ? WHERE id = ?")
        ->execute([$_POST['new_role'], $_POST['user_id']]);
    header("Location: admin_users.php"); exit();
}

// 3. Validation Mdp
if (isset($_GET['valider_mdp'])) {
    $req = $pdo->prepare("SELECT * FROM demandes_changement_mdp WHERE id = ?");
    $req->execute([$_GET['valider_mdp']]);
    $demande = $req->fetch();
    if ($demande) {
        $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE email = ?")
            ->execute([$demande['nouveau_pass_hash'], $demande['email']]);
        $pdo->prepare("DELETE FROM demandes_changement_mdp WHERE id = ?")->execute([$_GET['valider_mdp']]);
        header("Location: admin_users.php"); exit();
    }
}

$users = $pdo->query("SELECT * FROM utilisateurs")->fetchAll(PDO::FETCH_ASSOC);
$demandes = $pdo->query("SELECT * FROM demandes_changement_mdp")->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Panel Admin</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: 'Segoe UI', sans-serif; background: #f4f7f9; padding: 20px; }
        .container { max-width: 600px; margin: auto; }
        .card { background: white; padding: 20px; border-radius: 15px; box-shadow: 0 5px 15px rgba(0,0,0,0.05); margin-bottom: 20px; }
        .user-row { display: flex; justify-content: space-between; align-items: center; padding: 15px 0; border-bottom: 1px solid #eee; }
        select { padding: 5px; border-radius: 5px; border: 1px solid #ddd; }
        .btn-del { color: #d32f2f; margin-left: 10px; text-decoration: none; }
    </style>
</head>
<body>

<div class="container">
    <div class="card">
        <h3>Utilisateurs</h3>
        <?php foreach ($users as $u): ?>
            <div class="user-row">
                <div>
                    <strong><?= htmlspecialchars($u['nom_prenom']) ?></strong><br>
                    <small><?= $u['email'] ?></small>
                </div>
                <div style="display:flex; align-items:center;">
                    <form method="POST" style="margin-right:10px;">
                        <input type="hidden" name="user_id" value="<?= $u['id'] ?>">
                        <select name="new_role" onchange="this.form.submit()">
                            <option value="user" <?= $u['role'] == 'user' ? 'selected' : '' ?>>User</option>
                            <option value="moderateur" <?= $u['role'] == 'moderateur' ? 'selected' : '' ?>>Modérateur</option>
                            <option value="admin" <?= $u['role'] == 'admin' ? 'selected' : '' ?>>Admin</option>
                        </select>
                        <input type="hidden" name="update_role" value="1">
                    </form>
                    <a href="?delete=<?= $u['id'] ?>" class="btn-del" onclick="return confirm('Supprimer cet utilisateur ?')"><i class="fa-solid fa-trash"></i></a>
                </div>
            </div>
        <?php endforeach; ?>
    </div>
</div>

</body>
</html>
