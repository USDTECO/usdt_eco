<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family: sans-serif; }
        body { background: #e0e0e0 url('image/background.jpg') no-repeat center center fixed; background-size: cover; display: flex; justify-content: center; min-height: 100vh; }
        body::before { content: ""; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: inherit; filter: blur(4px); z-index: -1; }
        
        .mobile { width: 390px; min-height: 100vh; background: rgba(244, 247, 249, 0.95); padding: 20px; padding-bottom: 90px; box-shadow: 0 0 20px rgba(0,0,0,0.2); display: flex; flex-direction: column; position: relative; }
        
        /* En-tête avec logo et titre */
        .header-area { margin-bottom: 30px; }
        .logo { max-width: 120px; display: block; margin-bottom: 5px; }
        .page-title { font-size: 1.5rem; color: #333; font-weight: bold; }

        .card { background: white; width: 100%; padding: 30px; border-radius: 20px; box-shadow: 0 5px 15px rgba(0,0,0,0.1); text-align: center; }
        .icon-service { font-size: 50px; color: #1a237e; margin-bottom: 20px; }
        h2 { color: #333; margin-bottom: 10px; }
        p { color: #666; font-size: 0.9rem; margin-bottom: 25px; }
        
        .btn-contact { width: 100%; padding: 15px; background: #1a237e; color: white; border: none; border-radius: 10px; font-weight: bold; cursor: pointer; text-decoration: none; display: block; }
        .hours { margin-top: 20px; font-size: 0.8rem; color: #888; }

        /* Barre de navigation */
        .bottom-nav { position:fixed; bottom:0; width:390px; background:white; display:flex; justify-content:space-evenly; padding:12px 0; border-top:1px solid #eee; z-index:100; box-shadow: 0 -2px 10px rgba(0,0,0,0.05); }
        .nav-item { text-align:center; color:#777; font-size:10px; display:flex; flex-direction:column; align-items:center; gap:5px; cursor:pointer; }
        .nav-item i { font-size: 20px; }
        .nav-item.active { color:#1a237e; font-weight: bold; }
        a { text-decoration: none; }
    </style>
</head>
<body>

<div class="mobile">
    <div class="header-area">
        <img src="image/logo.png" alt="Logo" class="logo">
        <div class="page-title">Assistance</div>
    </div>

    <div class="card">
        <i class="fa-solid fa-headset icon-service"></i>
        <h2>Service en ligne</h2>
        <p>Si les utilisateurs ont des questions, veuillez contacter les services d'assistance.</p>
        
        <a href="mailto:finanzis.fr@gmail.com?subject=Demande d'assistance" class="btn-contact">
            Contactez maintenant
        </a>
        
        <div class="hours">Tous les jours : 10:00-23:00</div>
    </div>
</div>

<nav class="bottom-nav">
    <a href="index.php" class="nav-item"><i class="fa-solid fa-user"></i>Compte</a>
    <a href="activity.php" class="nav-item"><i class="fa-solid fa-chart-line"></i>Activité</a>
    <a href="assistance.php" class="nav-item active"><i class="fa-solid fa-headset"></i>Assistance</a>
    <a href="info.php" class="nav-item"><i class="fa-solid fa-circle-info"></i>À propos</a>
</nav>

<?php include 'traduction_script.php'; ?>


</body>
</html>