<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mon Profil</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* --- SÉCURITÉ ANTI-GOOGLE --- */
        html, body { top: 0 !important; position: relative !important; }
        .goog-te-banner-frame.skiptranslate, .goog-te-banner-frame, .goog-te-balloon-frame, #goog-gt-tt, .goog-te-gadget-icon, .skiptranslate iframe { display: none !important; }
        #google_translate_element { display: none !important; }

        * { margin:0; padding:0; box-sizing:border-box; font-family: sans-serif; }
        body { background: #f4f7f9; display: flex; justify-content: center; min-height: 100vh; }
        .mobile { width: 390px; background: #fff; min-height: 100vh; padding: 20px; padding-bottom: 90px; }

        .top-container { margin-bottom: 30px; }
        .logo { width: 120px; }
        .title { font-size: 1.5rem; font-weight: bold; color: black; margin: 10px 0; }
        .user-info { margin-bottom: 30px; }
        .user-name { font-size: 1.4rem; font-weight: bold; color: #1a237e; }
        .user-id { color: #666; font-size: 0.9rem; }

        .menu-list { list-style: none; }
        .menu-item { display: flex; align-items: center; padding: 18px 0; border-bottom: 1px solid #f0f0f0; cursor: pointer; text-decoration: none; color: #333; position: relative; }
        .menu-item i { width: 40px; font-size: 1.2rem; color: #1a237e; }
        .menu-item span { flex: 1; font-weight: 500; }
        .arrow { color: #ccc; }
        
        /* Menu Langue */
        .lang-menu { display: none; position: absolute; right: 0; top: 50px; background: white; border-radius: 10px; padding: 10px; list-style: none; box-shadow: 0 5px 15px rgba(0,0,0,0.2); z-index: 1000; }
        .lang-menu li { padding: 8px 15px; cursor: pointer; font-size: 14px; }
        .lang-menu li:hover { background: #f0f0f0; }
        .section-divider { margin: 20px 0 10px 0; font-size: 0.75rem; color: #999; text-transform: uppercase; font-weight: bold; }
    </style>
</head>
<body>

<div class="mobile">
    <div class="top-container">
       <div style="text-align:center;"> <img src="image/logo.png" alt="Logo" class="logo"></div>
        <div class="title">Compte</div>
    </div>

    <div class="user-info">
        <div class="user-name"><?php echo htmlspecialchars($user['nom_prenom']); ?></div>
        <div class="user-id">ID: <?php echo htmlspecialchars($user['code_personnel']); ?></div>
    </div>

    <div class="menu-list">
        <a href="kyc.php" class="menu-item">
            <i class="fa-solid fa-shield-halved"></i> <span>Vérification KYC</span> <i class="fa-solid fa-chevron-right arrow"></i>
        </a>
        <a href="parametres.php" class="menu-item">
            <i class="fa-solid fa-gear"></i> <span>Paramètres</span> <i class="fa-solid fa-chevron-right arrow"></i>
        </a>
        <a href="assistance.php" class="menu-item">
            <i class="fa-solid fa-headset"></i> <span>Support</span> <i class="fa-solid fa-chevron-right arrow"></i>
        </a>
        <a href="historique.php" class="menu-item">
            <i class="fa-solid fa-clock-rotate-left"></i> <span>Historique</span> <i class="fa-solid fa-chevron-right arrow"></i>
        </a>
        
        <div class="menu-item" onclick="document.getElementById('lang-list').style.display = (document.getElementById('lang-list').style.display === 'block' ? 'none' : 'block');">
            <i class="fa-solid fa-language"></i> <span>Langue</span> 
            <i class="fa-solid fa-globe" style="width: auto; color: #00796b;"></i>
            <ul id="lang-list" class="lang-menu">
                <li onclick="changeLanguage('fr')">🇨🇵 Français</li>
                <li onclick="changeLanguage('en')">🇺🇲 English</li>
                <li onclick="changeLanguage('de')">🇩🇪 Deutsch</li>
                <li onclick="changeLanguage('es')">🇪🇦 Español</li>
                <li onclick="changeLanguage('tr')">🇹🇷 Türkçe</li>
                <li onclick="changeLanguage('cs')">🇨🇿 Čeština</li>
            </ul>
        </div>

        <div class="section-divider">Informations légales</div>
        <a href="info.php?page=confidentialite" class="menu-item">
            <i class="fa-solid fa-lock"></i> <span>Règle de confidentialité</span> <i class="fa-solid fa-chevron-right arrow"></i>
        </a>
        <a href="info.php?page=securite" class="menu-item">
            <i class="fa-solid fa-user-shield"></i> <span>Transparence et sécurité</span> <i class="fa-solid fa-chevron-right arrow"></i>
        </a>
        <a href="info.php?page=conditions" class="menu-item">
            <i class="fa-solid fa-file-contract"></i> <span>Condition d'utilisation</span> <i class="fa-solid fa-chevron-right arrow"></i>
        </a>

        <a href="logout.php" class="menu-item" style="color: #d32f2f; margin-top: 20px;">
            <i class="fa-solid fa-right-from-bracket"></i> <span>Déconnexion</span>
        </a>
    </div>
</div>

<div id="google_translate_element"></div>
<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({pageLanguage: 'fr', autoDisplay: false}, 'google_translate_element');
    }
    function changeLanguage(lang) {
        var combo = document.querySelector('.goog-te-combo');
        if (combo) {
            combo.value = lang;
            combo.dispatchEvent(new Event('change'));
        }
        localStorage.setItem('userLanguage', lang);
    }
    window.onload = function() {
        var saved = localStorage.getItem('userLanguage');
        if(saved) setTimeout(function(){ changeLanguage(saved); }, 1000);
    };
    setInterval(function() { document.body.style.top = "0px"; }, 50);
</script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>

<?php include 'traduction_script.php'; ?>


</body>
</html>