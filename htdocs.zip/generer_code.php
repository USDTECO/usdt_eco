<?php
require_once 'db.php';
$nouveau_code = "";

if (isset($_POST['generer'])) {
    // Génère un code alphanumérique de 8 caractères
    $nouveau_code = strtoupper(substr(bin2hex(random_bytes(4)), 0, 8));
    $stmt = $pdo->prepare("INSERT INTO codes_invitation (code) VALUES (?)");
    $stmt->execute([$nouveau_code]);
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Générateur de Codes</title>
    <style>
        body { font-family: sans-serif; background: #eef2f5; display: flex; justify-content: center; padding: 20px; }
        .box { width: 390px; background: white; padding: 30px; border-radius: 25px; box-shadow: 0 10px 25px rgba(0,0,0,0.1); text-align: center; }
        h2 { color: #1a237e; margin-bottom: 25px; }
        button { width: 100%; padding: 15px; background: #1a237e; color: white; border: none; border-radius: 12px; font-weight: bold; cursor: pointer; }
        .code-display { margin-top: 25px; padding: 20px; background: #f4f7f9; border-radius: 15px; border: 2px dashed #1a237e; }
        .code-text { font-size: 24px; font-weight: bold; color: #1a237e; letter-spacing: 2px; }
    </style>
</head>
<body>
    <div class="box">
        <h2>Générateur de Codes</h2>
        <form method="POST">
            <button name="generer">Générer un nouveau code</button>
        </form>

        <?php if($nouveau_code): ?>
            <div class="code-display">
                <p>Code généré avec succès :</p>
                <div class="code-text"><?php echo $nouveau_code; ?></div>
            </div>
        <?php endif; ?>
    </div>
</body>
</html>
