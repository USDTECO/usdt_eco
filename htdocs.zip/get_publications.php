<?php
session_start();
require_once 'db.php';

// On récupère toutes les publications pour pouvoir afficher les désactivées
$pubs = $pdo->prepare("SELECT * FROM publications WHERE user_id = ? ORDER BY id DESC");
$pubs->execute([$_SESSION['user_id']]);
$liste_pubs = $pubs->fetchAll();

if (empty($liste_pubs)) {
    echo '<div class="empty-state"><i class="fa-solid fa-vault"></i><p>Aucune demande pour le moment.</p></div>';
} else {
    foreach($liste_pubs as $p) {
        $id = (int)$p['id'];
        $dispo = (int)$p['disponible'];
        // Style visuel si l'offre est désactivée (optionnel)
        $style = $dispo == 0 ? 'style="opacity: 0.6; filter: grayscale(1);"' : '';
        
        echo '<div class="pub-item" '.$style.'>
            <i class="fa-solid fa-trash btn-delete" onclick="showModal(\'delete\', '.$id.')"></i>
            <div class="flex-container">
                <img src="'.htmlspecialchars($p['image_url']).'" class="img-pub">
                <div class="details">
                    <span class="title">'.htmlspecialchars($p['titre']).'</span>
                    <div class="desc">'.htmlspecialchars($p['description']).'</div>
                </div>
            </div>
            <div class="grid-info">
                <div><small style="color:#888">Solde</small><br><span class="value">$'.htmlspecialchars($p['solde']).'</span></div>
                <div><small style="color:#888">Commission</small><br><span class="value" style="color: #2e7d32;">$'.htmlspecialchars($p['profit']).'</span></div>
            </div>
            <button class="btn-accept" onclick="showModal(\'accept\', '.$id.', \''.htmlspecialchars($p['solde']).'\', \''.htmlspecialchars($p['profit']).'\', '.$dispo.')">
                '.($dispo ? 'Accepter la demande' : 'Offre indisponible').'
            </button>
        </div>';
    }
}
?>
