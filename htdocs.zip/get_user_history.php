<?php
require_once 'db.php';
$stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC");
$stmt->execute([$_GET['user_id']]);
$trans = $stmt->fetchAll();

echo "<table><tr><th>Type</th><th>Montant</th><th>Date</th><th>Action</th></tr>";
foreach ($trans as $t) {
    echo "<tr>
            <td>{$t['type']}</td>
            <td><input type='number' id='m_{$t['id']}' value='{$t['montant']}'></td>
            <td><input type='text' id='d_{$t['id']}' value='{$t['date']}'></td>
            <td>
                <button onclick='saveTrans({$t['id']})'>Save</button>
                <a href='?delete={$t['id']}'>X</a>
            </td>
          </tr>";
}
echo "</table>";
?>
