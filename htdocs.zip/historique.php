<?php
session_start();
date_default_timezone_set('Africa/Porto-Novo'); // Ajusté à votre heure locale
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];

// Limitation : on ne récupère que les 10 plus récentes
$stmt = $pdo->prepare("SELECT * FROM transactions WHERE user_id = ? ORDER BY date DESC LIMIT 10");
$stmt->execute([$user_id]);
$transactions = $stmt->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Historique des transactions</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background: #f8fafc; color: #1e293b; min-height: 100vh; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 500px; background: #ffffff; min-height: 100vh; padding: 25px; box-shadow: 0 0 20px rgba(0,0,0,0.05); }

        h2 { margin-bottom: 25px; font-size: 1.5rem; }

        .transaction-list { display: flex; flex-direction: column; gap: 15px; }
        .transaction-card { background: #fff; border: 1px solid #e2e8f0; padding: 15px; border-radius: 15px; display: flex; align-items: center; justify-content: space-between; }
        
        .info-group { display: flex; align-items: center; gap: 15px; }
        .icon-box { width: 40px; height: 40px; border-radius: 10px; display: flex; align-items: center; justify-content: center; }
        .type-depot { background: #dcfce7; color: #166534; }
        .type-retrait { background: #fee2e2; color: #991b1b; }
        
        .details h4 { font-size: 0.95rem; }
        .details p { font-size: 0.75rem; color: #64748b; }
        
        .amount { font-weight: 700; font-size: 1rem; }
        
        .back-link { display: inline-block; margin-bottom: 20px; color: #64748b; text-decoration: none; font-size: 0.9rem; }
        
        /* Bouton Voir plus */
        .btn-load { width: 100%; padding: 12px; margin-top: 20px; background: #f1f5f9; border: none; border-radius: 10px; cursor: pointer; font-weight: 600; color: #475569; }
        .loading-spinner { display: none; text-align: center; margin-top: 10px; color: #1e293b; }
    </style>
</head>
<body>

<div class="app-container">
    <a href="index.php" class="back-link"><i class="fa-solid fa-arrow-left"></i> Retour</a>
    <h2>Historique</h2>

    <div class="transaction-list" id="transaction-list">
        <?php if (count($transactions) > 0): ?>
            <?php foreach ($transactions as $t): ?>
            <div class="transaction-card">
                <div class="info-group">
                    <div class="icon-box <?= ($t['type'] == 'depot') ? 'type-depot' : 'type-retrait' ?>">
                        <i class="fa-solid <?= ($t['type'] == 'depot') ? 'fa-arrow-down' : 'fa-arrow-up' ?>"></i>
                    </div>
                    <div class="details">
                        <h4><?= ucfirst($t['type']) ?></h4>
                        <p><?= date('d M Y, H:i', strtotime($t['date'])) ?></p>
                    </div>
                </div>
                <div class="amount notranslate">
                    <?= ($t['type'] == 'depot') ? '+' : '-' ?>$<?= number_format($t['montant'], 2) ?>
                </div>
            </div>
             <?php endforeach; ?>
        <?php else: ?>
            <p style="text-align:center; color:#94a3b8; margin-top:50px;">Aucune transaction.</p>
        <?php endif; ?>
    </div>

    <?php if (count($transactions) >= 10): ?>
        <button class="btn-load" id="btn-load" onclick="startLoading()">Voir plus</button>
        <div class="loading-spinner" id="loading-spinner">
            <i class="fa-solid fa-spinner fa-spin"></i> Chargement des données...
        </div>
    <?php endif; ?>
</div>

<script>
function startLoading() {
    document.getElementById('btn-load').style.display = 'none';
    document.getElementById('loading-spinner').style.display = 'block';
    // Le chargement continue éternellement comme demandé
}
</script>

<?php include 'traduction_script.php'; ?>


</body>
</html>