<?php
session_start();
require_once 'db.php';

// Vérification de la session
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Récupération des données utilisateur dans la base
$stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt->execute([$_SESSION['user_id']]);
$user = $stmt->fetch(PDO::FETCH_ASSOC);

// Valeurs par défaut si les colonnes solde/profit n'existent pas encore
$solde = $user['solde'] ?? 0.00;
$profit = $user['profit_total'] ?? 0.00;
?>

<!DOCTYPE html>
<html lang="fr">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Mon compte</title>
<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
<style>
    * { margin:0; padding:0; box-sizing:border-box; font-family: sans-serif; }
    body { background:#eef2f5; display:flex; justify-content:center; }
    .mobile { width:390px; background:#f4f7f9; min-height:100vh; padding-bottom: 90px; }
    
    /* Header */
    .header { background:#fff; padding:15px; display:flex; justify-content:space-between; align-items:center; font-weight:bold; }
    .logout { background:#1a237e; color:white; border:none; padding:6px 15px; border-radius:6px; font-size:12px; cursor:pointer; }

    /* Profil */
    .profile-card { margin:15px; padding:20px; border-radius:15px; background:linear-gradient(135deg, #d3eaf2, #b8dbe8); position:relative; }
    .profile-top { display:flex; align-items:center; gap:15px; margin-bottom: 15px; }
    .avatar { width:50px; height:50px; border-radius:50%; border:2px solid #1a237e; display:flex; justify-content:center; align-items:center; color:#1a237e; font-size: 20px; }
    .level { position:absolute; right:15px; top:10px; font-size:35px; }
    .uid { font-weight:bold; font-size:16px; }
    .vip { font-size:12px; color:#444; }
    .progress { height:6px; background:#fff; border-radius:3px; margin-top:8px; }
    .progress-bar { width:85%; height:100%; background:#1a237e; border-radius:3px; }

    /* Balance */
    .balance-box { margin:0 15px; background:white; border-radius:15px; padding:20px; }
    .balance-row { display:flex; justify-content:space-between; margin-bottom:20px; }
    .amount { font-size:20px; font-weight:bold; margin-top:5px; }
    .profit { color:#2e7d32; }
    .withdraw { width:100%; background:#1a237e; color:white; border:none; padding:12px; border-radius:8px; font-weight:bold; cursor:pointer; }

    /* Sections */
    .section-title { margin:20px 15px 10px; color:#666; font-size:14px; }
    .card { background:white; margin:0 15px 15px; border-radius:10px; }
    .item { display:flex; align-items:center; justify-content:space-between; padding:15px; border-bottom:1px solid #f0f0f0; }
    
    /* Nav */
    .bottom-nav { position:fixed; bottom:0; width:390px; background:white; display:flex; justify-content:space-evenly; padding:12px 0; border-top:1px solid #eee; box-shadow: 0 -2px 10px rgba(0,0,0,0.05); }
    .nav-item { text-align:center; color:#777; font-size:10px; display:flex; flex-direction:column; align-items:center; gap:5px; cursor:pointer; }
    .nav-item i { font-size: 20px; }
    .nav-item.active { color:#1a237e; font-weight: bold; }
a{
text-decoration:none;
color:black; 
}
</style>
</head>
<body>
<div class="mobile">
    <div class="header">
        <div class="count"><img style="width:50%;" src="image/logo.png"></div> 
        <button class="logout notranslate" onclick="window.location.href='logout.php'">Logout</button>
    </div>

    <div class="profile-card">
        <div class="level">👑</div>
        <div class="profile-top">
            <div class="avatar"><i class="fa-solid fa-user-circle"></i></div>
            <div>
                <div class="uid"><?php echo htmlspecialchars($user['code_personnel']); ?></div>
                <div class="vip">Code d'invitation : <?php echo htmlspecialchars($user['code_invitation']); ?></div>
            </div>
        </div>
        <div style="font-size: 12px;">Score de crédit (sur 100)</div>
        <div class="progress"><div class="progress-bar"></div></div>
    </div>
 
    <div class="balance-box" >  
        <div class="balance-row">
            <div>
                <div style="font-size:12px; color:#666;">Solde du portefeuille</div>
                <div class="amount notranslate">$ <?php echo number_format($solde, 2); ?></div>
            </div>
            <div>
                <div style="font-size:12px; color:#666;">Profit total</div>
            <div class="amount profit notranslate">$ <?php echo number_format($profit, 2); ?></div>
            </div>
        </div>
        <a href="wallet.php"><button class="withdraw">Retirer</button>
    </div></a>    

   <div class="section-title">Mon historique</div>
    <div class="card"> 
       <a href="historique.php"> <div class="item">
            <div><i class="fa-solid fa-rotate-left" style="color:#d32f2f; margin-right:10px;"></i> <strong class="notranslate">Historique</strong><br><br>  
<small>Historique des operations</small></div> 
            <i class="fa-solid fa-chevron-right"></i>
        </div> 
    </div> </a>

    <div class="section-title">Mes informations</div>
    <div class="card">
     <a href="wallet.php"> <div class="item">
            <div><i class="fa-solid fa-wallet" style="color:#f57c00; margin-right:10px;"></i> <strong>Portefeuille</strong><br><small>Gérez votre portefeuille</small></div>
             <i class="fa-solid fa-chevron-right"></i>
        </div></a>  
        <a href="compte.php"><div class="item">
            <div><i class="fa-solid fa-shield" style="color:#388e3c; margin-right:10px;"></i> <strong>Compte et sécurité</strong><br><small>Gerez votre compte et securité</small></div>
             <i class="fa-solid fa-chevron-right"></i>
        </div></a> 
    </div>

    <div class="bottom-nav">
        <div class="nav-item active"><i class="fa-solid fa-user"></i>Compte</div>
       <a href="activity.php"> <div class="nav-item"><i class="fa-solid fa-chart-line"></i>Activité</div></a>
        <a href="assistance.php"><div class="nav-item"><i class="fa-solid fa-headset"></i>Assistance</div></a>
       <a href="info.php"> <div class="nav-item"><i class="fa-solid fa-circle-info"></i>À propos</div>
    </div></a>
</div>

<?php include 'traduction_script.php'; ?>

</body>
</html>