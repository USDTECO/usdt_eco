<?php
session_start();
if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family: 'Segoe UI', sans-serif; }
        body { background:#eef2f5; display:flex; justify-content:center; min-height:100vh; }
        .mobile { width:390px; background:#f4f7f9; min-height:100vh; padding-bottom: 90px; position: relative; }
        
        .header { background:#fff; padding:15px; display:flex; align-items:center; justify-content:center; box-shadow: 0 2px 5px rgba(0,0,0,0.05); }
        .logo { width: 120px; }

        .content { padding: 20px; }
        h2 { color: #1a237e; margin-bottom: 20px; font-size: 1.4rem; }
        h3 { color: #1a237e; font-size: 1.1rem; margin-top: 20px; margin-bottom: 10px; }
        p { color: #555; line-height: 1.6; margin-bottom: 12px; font-size: 0.85rem; text-align: justify; }
        .card { background: white; padding: 20px; border-radius: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.05); margin-bottom: 20px; }
        
        .highlight { color: #2e7d32; font-weight: bold; }

        .bottom-nav { position:fixed; bottom:0; width:390px; background:white; display:flex; justify-content:space-evenly; padding:12px 0; border-top:1px solid #eee; z-index: 100; }
        .nav-item { text-align:center; color:#777; font-size:10px; display:flex; flex-direction:column; align-items:center; gap:5px; cursor:pointer; text-decoration:none; }
        .nav-item i { font-size: 20px; }
        .nav-item.active { color:#1a237e; font-weight: bold; }
    </style>
</head>
<body>

<div class="mobile">
    <div class="header">
        <img src="image/logo.png" alt="Logo" class="logo">
    </div>

    <div class="content">
        <h2>À Propos de notre écosystème</h2>
        
        <div class="card">
            <h3>Règle de confidentialité</h3>
            <p>La protection de vos données personnelles est au cœur de notre engagement. Toutes les informations collectées lors de votre inscription et de l'utilisation de nos services sont traitées avec une stricte confidentialité.</p>
            <p>Nous nous engageons à ne jamais vendre ni partager vos données personnelles avec des tiers sans votre consentement préalable, sauf exigence légale ou judiciaire.</p>
        </div>

        <div class="card">
            <h3>Notre Mission</h3>
            <p>Notre plateforme agit comme un pont technologique entre les institutions bancaires traditionnelles et les besoins de financement rapide. Nous prenons en charge les micro-prêts à court terme que les banques ne peuvent traiter instantanément.</p>
        </div>

        <div class="card">
            <h3>Le Modèle de Rendement</h3>
            <p>En participant au financement de ces demandes, vous agissez comme un facilitateur de crédit. Chaque transaction validée permet d'obtenir une commission fixe garantie de <span class="highlight">25%</span> sur le capital investi.</p>
        </div>

        <div class="card">
            <h3>Sécurité et Transparence</h3>
            <p>La sécurité de vos actifs est notre priorité absolue. Nous utilisons des protocoles de chiffrement de niveau bancaire. Chaque mouvement est traçable, et le système de vérification des utilisateurs garantit un environnement sain.</p>
        </div>

        <div class="card">
            <h3>Conditions d'utilisation</h3>
            <p>En utilisant ce service, vous acceptez que les fonds déposés soient utilisés pour la facilitation des micro-prêts. La validation d'une offre constitue un engagement ferme.</p>
        </div>
    </div>

    <nav class="bottom-nav">
        <a href="index.php" class="nav-item"><i class="fa-solid fa-user"></i>Compte</a>
        <a href="activity.php" class="nav-item"><i class="fa-solid fa-chart-line"></i>Activité</a>
        <a href="assistance.php" class="nav-item"><i class="fa-solid fa-headset"></i>Assistance</a>
        <a href="info.php" class="nav-item active"><i class="fa-solid fa-circle-info"></i>À propos</a>
    </nav>
</div>

<?php include 'traduction_script.php'; ?>


</body>
</html>