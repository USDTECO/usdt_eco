<?php
require_once 'db.php';
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $nom = $_POST['nom']; $email = $_POST['email']; $dob = $_POST['dob'];
    $pays = $_POST['pays']; $pass = $_POST['password']; $code_saisi = $_POST['code'];
    
    $check_email = $pdo->prepare("SELECT id FROM utilisateurs WHERE email = ?");
    $check_email->execute([$email]);
    
    $check_code = $pdo->prepare("SELECT id FROM codes_invitation WHERE code = ? AND est_utilise = 0");
    $check_code->execute([$code_saisi]);
    
    if ($check_email->fetch()) {
        $message = "<div class='message-box error'>Cet e-mail est déjà utilisé.</div>";
    } elseif (!$check_code->fetch()) {
        $message = "<div class='message-box error'>Code d'invitation invalide ou déjà utilisé.</div>";
    } else {
        $code_perso = mt_rand(10000000, 99999999);
        $hashed_pass = password_hash($pass, PASSWORD_DEFAULT);
        
        $insert = $pdo->prepare("INSERT INTO utilisateurs (nom_prenom, email, date_naissance, pays, mot_de_passe, code_invitation, code_personnel) VALUES (?, ?, ?, ?, ?, ?, ?)");
        $insert->execute([$nom, $email, $dob, $pays, $hashed_pass, $code_saisi, $code_perso]);
        
        $pdo->prepare("UPDATE codes_invitation SET est_utilise = 1 WHERE code = ?")->execute([$code_saisi]);
        
        header("Location: login.php?success=1");
        exit();
    }
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sign Up</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* --- SÉCURITÉ ANTI-GOOGLE --- */
        html, body { top: 0 !important; position: relative !important; }
        .goog-te-banner-frame.skiptranslate, .goog-te-banner-frame, .goog-te-banner, 
        .goog-te-balloon-frame, #goog-gt-tt, .goog-te-gadget-icon, .skiptranslate iframe { display: none !important; visibility: hidden !important; }
        #google_translate_element { display: none !important; }

        body, html { margin: 0; padding: 0; height: 100%; font-family: sans-serif; }
        body { background: url('image/background.jpg') no-repeat center center fixed; background-size: cover; display: flex; justify-content: center; align-items: center; }
        
        .box { width: 90%; max-width: 390px; background: rgba(255, 255, 255, 0.2); padding: 30px 20px; border-radius: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); backdrop-filter: blur(15px); border: 1px solid rgba(255,255,255,0.3); box-sizing: border-box; }
        
        /* Menu Globe */
        .header-icons { display: flex; justify-content: flex-end; margin-bottom: 10px; position: relative; }
        .lang-icon { color: white; font-size: 24px; cursor: pointer; }
        .lang-menu { display: none; position: absolute; top: 30px; right: 0; background: white; border-radius: 10px; padding: 10px; list-style: none; box-shadow: 0 5px 15px rgba(0,0,0,0.2); z-index: 1000; }
        .lang-menu li { padding: 5px 10px; cursor: pointer; font-size: 14px; }
        .lang-menu li:hover { background: #f0f0f0; }
        .header-icons:hover .lang-menu { display: block; }

        .logo-container { text-align: center; margin-bottom: 20px; }
        .logo-container img { width: 70%; max-width: 250px; height: auto; object-fit: contain; } 
        h2 { color: white; text-align: center; margin-bottom: 20px; font-size: 24px; }
        
        .input-group { position: relative; margin-bottom: 15px; }
        .input-group i { position: absolute; left: 15px; top: 15px; color: #1a237e; }
        input { width: 100%; padding: 14px 14px 14px 45px; border: none; background: rgba(255,255,255,0.9); border-radius: 12px; outline: none; box-sizing: border-box; }
        
        button { width: 100%; padding: 14px; background: #1a237e; color: white; border: none; border-radius: 12px; font-weight: bold; cursor: pointer; margin-top: 5px; }
        .message-box { padding: 12px; border-radius: 12px; text-align: center; margin-bottom: 20px; font-size: 14px; font-weight: bold; }
        .error { background: rgba(220, 53, 69, 0.3); color: #ffcdd2; border: 1px solid rgba(220, 53, 69, 0.5); backdrop-filter: blur(5px); }
        .footer-link { text-align: center; margin-top: 15px; font-size: 14px; color: white; }
        .footer-link a { color: #fff; text-decoration: underline; font-weight: bold; }
    </style>
</head>
<body>
    <div class="box">
        <div class="header-icons">
            <i class="fa-solid fa-globe lang-icon"></i>
            <ul class="lang-menu">
                <li onclick="changeLanguage('fr')">🇨🇵 Français</li>
                <li onclick="changeLanguage('en')">🇺🇲 English</li>
                <li onclick="changeLanguage('de')">🇩🇪 Deutsch</li>
                <li onclick="changeLanguage('es')">🇪🇦 Español</li>
                <li onclick="changeLanguage('tr')">🇹🇷 Türkçe</li>
                <li onclick="changeLanguage('cs')">🇨🇿 Čeština</li>
            </ul>
        </div>
        
        <div id="google_translate_element"></div>

        <div class="logo-container"><img src="image/logo.png" alt="Logo"></div>
        <h2>Sign Up</h2>
        <?php if($message) echo $message; ?>
        <form method="POST">
            <div class="input-group"><i class="fa-solid fa-user"></i><input type="text" name="nom" placeholder="Nom et prénom" required></div>
            <div class="input-group"><i class="fa-solid fa-envelope"></i><input type="email" name="email" placeholder="Adresse e-mail" required></div>
            <div class="input-group"><i class="fa-solid fa-calendar"></i><input type="text" name="dob" placeholder="JJ/MM/AAAA" required></div>
            <div class="input-group"><i class="fa-solid fa-earth-americas"></i><input type="text" name="pays" placeholder="Pays" required></div>
            <div class="input-group"><i class="fa-solid fa-lock"></i><input type="password" name="password" placeholder="Mot de passe" required></div>
            <div class="input-group"><i class="fa-solid fa-gift"></i><input type="text" name="code" placeholder="Code d'invitation" required></div>
            <button type="submit">CRÉER COMPTE</button>
        </form>
        <div class="footer-link">Déjà un compte ? <a href="login.php">Sign in</a></div>
    </div>

    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'fr', autoDisplay: false}, 'google_translate_element');
        }
        function changeLanguage(lang) {
            var combo = document.querySelector('.goog-te-combo');
            if (combo) {
                combo.value = lang;
                combo.dispatchEvent(new Event('change'));
            }
            localStorage.setItem('userLanguage', lang);
        }
        window.onload = function() {
            setTimeout(function() {
                var saved = localStorage.getItem('userLanguage');
                if(saved) changeLanguage(saved);
            }, 1000);
        };
        setInterval(function() { document.body.style.top = "0px"; }, 50);
    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</body>
</html>