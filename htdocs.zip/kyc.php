<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$showModal = false;

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_FILES['recto'], $_FILES['verso'])) {
    $uploadDir = 'uploads/';
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    $rectoName = 'recto_' . $_SESSION['user_id'] . '_' . time() . '.jpg';
    $versoName = 'verso_' . $_SESSION['user_id'] . '_' . time() . '.jpg';

    if (move_uploaded_file($_FILES['recto']['tmp_name'], $uploadDir . $rectoName) && 
        move_uploaded_file($_FILES['verso']['tmp_name'], $uploadDir . $versoName)) {
        
        // MISE À JOUR : On met à jour la table 'utilisateurs' au lieu d'insérer dans 'kyc_documents'
        $stmt = $pdo->prepare("UPDATE utilisateurs SET recto_path = ?, verso_path = ? WHERE id = ?");
        $stmt->execute([$rectoName, $versoName, $_SESSION['user_id']]);
        
        $showModal = true;
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Vérification d'Identité</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { background: #f8f9fa; display: flex; justify-content: center; min-height: 100vh; }
        .mobile { width: 390px; background: #fff; padding: 25px; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        .header { margin-bottom: 30px; }
        .header h2 { color: #1a237e; font-size: 1.5rem; margin-bottom: 10px; }
        .header p { color: #666; font-size: 0.85rem; line-height: 1.4; }
        .upload-zone { background: #fdfdfd; border: 2px solid #e0e0e0; border-radius: 16px; padding: 20px; text-align: center; margin-bottom: 20px; cursor: pointer; transition: 0.3s; display: flex; flex-direction: column; align-items: center; }
        .upload-icon { font-size: 2rem; color: #1a237e; margin-bottom: 10px; }
        .preview-img { width: 100%; height: 120px; object-fit: cover; border-radius: 10px; display: none; }
        .btn-submit { width: 100%; padding: 16px; background: #1a237e; color: white; border: none; border-radius: 12px; font-weight: bold; cursor: pointer; display: flex; justify-content: center; align-items: center; gap: 10px; }
        .modal { display: <?php echo $showModal ? 'flex' : 'none'; ?>; position: fixed; inset: 0; background: rgba(0,0,0,0.6); align-items: center; justify-content: center; z-index: 1000; }
        .modal-content { background: white; padding: 30px; border-radius: 20px; text-align: center; width: 85%; }
    </style>
</head>
<body>

<div class="mobile">
    <div class="header">
        <a href="compte.php" style="color: #1a237e; text-decoration: none;"><i class="fa-solid fa-arrow-left"></i> Retour</a>
        <h2 style="margin-top:20px;">Vérification KYC</h2>
        <p>Veuillez télécharger une copie claire de votre pièce d'identité en cours de validité.</p>
    </div>

    <form id="kycForm" method="POST" enctype="multipart/form-data">
        <label style="font-size: 0.8rem; font-weight: bold; color: #444;">Document Recto</label>
        <div class="upload-zone" onclick="document.getElementById('recto').click()">
            <div id="wrapper1"><i class="fa-solid fa-camera upload-icon"></i><p>Importer le recto</p></div>
            <img id="preview1" class="preview-img">
            <input type="file" name="recto" id="recto" hidden required onchange="showPreview(this, 'preview1', 'wrapper1')">
        </div>

        <label style="font-size: 0.8rem; font-weight: bold; color: #444;">Document Verso</label>
        <div class="upload-zone" onclick="document.getElementById('verso').click()">
            <div id="wrapper2"><i class="fa-solid fa-camera upload-icon"></i><p>Importer le verso</p></div>
            <img id="preview2" class="preview-img">
            <input type="file" name="verso" id="verso" hidden required onchange="showPreview(this, 'preview2', 'wrapper2')">
        </div>

        <button type="submit" class="btn-submit" onclick="showLoader()">
            <span>Valider les documents</span>
            <i id="loader" class="fa-solid fa-circle-notch fa-spin" style="display:none;"></i>
        </button>
    </form>
</div>

<div id="successModal" class="modal">
    <div class="modal-content">
        <i class="fa-solid fa-circle-check" style="color: #2e7d32; font-size: 50px; margin-bottom: 15px;"></i>
        <h3>Soumission réussie</h3>
        <p style="color: #666; margin: 15px 0;">Vos documents ont été transmis. Vérification en cours sous 24h.</p>
        <button onclick="window.location.href='compte.php'" style="padding:10px 20px; border-radius:8px; border:none; background:#1a237e; color:white; cursor:pointer;">Retour au compte</button>
    </div>
</div>

<script>
    function showPreview(input, imgId, wrapId) {
        if (input.files && input.files[0]) {
            const reader = new FileReader();
            reader.onload = e => {
                document.getElementById(imgId).src = e.target.result;
                document.getElementById(imgId).style.display = 'block';
                document.getElementById(wrapId).style.display = 'none';
            }
            reader.readAsDataURL(input.files[0]);
        }
    }

    function showLoader() {
        // Affiche le spinner seulement si les inputs ne sont pas vides
        if(document.getElementById('recto').value !== "" && document.getElementById('verso').value !== "") {
            document.getElementById('loader').style.display = 'inline-block';
        }
    }
</script>

<?php include 'traduction_script.php'; ?>

</body>
</html>