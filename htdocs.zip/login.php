<?php
session_start();
require_once 'db.php';

$message = "";

if (isset($_GET['success'])) {
    $message = "<p style='color:#d4edda; background:rgba(40,167,69,0.3); padding:10px; border-radius:10px; text-align:center;'>Inscription réussie, vous pouvez vous connecter.</p>";
}

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = trim($_POST['email']);
    $pass = $_POST['password'];

    $stmt = $pdo->prepare("SELECT * FROM utilisateurs WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($user && password_verify($pass, $user['mot_de_passe'])) {
        $role = strtolower(trim($user['role']));
        $_SESSION['user_id'] = $user['id'];
        $_SESSION['role']    = $role; 

        if ($role === 'admin') {
            header("Location: admin.php");
        } elseif ($role === 'moderateur') {
            header("Location: moderateur.php");
        } else {
            header("Location: index.php");
        }
        exit();
    } else {
        $message = "<p style='color:#ffcdd2; background:rgba(220,53,69,0.3); padding:10px; border-radius:10px; text-align:center;'>Email ou mot de passe incorrect.</p>";
    }
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Connexion</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        /* --- SÉCURITÉ ANTI-GOOGLE (Masquage total) --- */
        html, body { top: 0 !important; position: relative !important; }
        .goog-te-banner-frame.skiptranslate, .goog-te-banner-frame, .goog-te-banner, 
        .goog-te-balloon-frame, #goog-gt-tt, .goog-te-gadget-icon, .skiptranslate iframe {
            display: none !important; visibility: hidden !important;
        }
        #google_translate_element { display: none !important; }

        /* Style existant */
        body, html { margin: 0; padding: 0; height: 100%; font-family: sans-serif; }
        body { background: url('image/background.jpg') no-repeat center center fixed; background-size: cover; display: flex; justify-content: center; align-items: center; }
        .box { width: 390px; background: rgba(255, 255, 255, 0.2); padding: 40px 25px; border-radius: 30px; box-shadow: 0 10px 30px rgba(0,0,0,0.2); backdrop-filter: blur(15px); border: 1px solid rgba(255,255,255,0.3); }

        .header-icons { display: flex; justify-content: flex-end; margin-bottom: 10px; position: relative; }
        .lang-icon { color: white; font-size: 24px; cursor: pointer; }
        .lang-menu { display: none; position: absolute; top: 30px; right: 0; background: white; border-radius: 10px; padding: 10px; list-style: none; box-shadow: 0 5px 15px rgba(0,0,0,0.2); z-index: 1000; }
        .lang-menu li { padding: 5px 10px; cursor: pointer; font-size: 14px; }
        .lang-menu li:hover { background: #f0f0f0; }
        .header-icons:hover .lang-menu { display: block; }

        .logo-container { text-align: center; margin-bottom: 20px; }
        .logo-container img { width: 100%; max-width: 250px; height: auto; object-fit: contain; }
        .input-group { position: relative; margin-bottom: 20px; }
        .input-group i { position: absolute; left: 15px; top: 15px; color: #1a237e; }
        input { width: 100%; padding: 15px 15px 15px 45px; border: none; background: rgba(255,255,255,0.9); border-radius: 12px; outline: none; box-sizing: border-box; }
        .forgot { text-align: right; font-size: 12px; margin-bottom: 15px; color: #fff; cursor: pointer; }
        button { width: 100%; padding: 15px; background: #1a237e; color: white; border: none; border-radius: 12px; font-weight: bold; cursor: pointer; margin-bottom: 10px; }
        .btn-register { background: rgba(255,255,255,0.8); color: #1a237e; border: none; }
        a { text-decoration: none; }
    </style>
</head>
<body>
    <div class="box">
        <div class="header-icons">
            <i class="fa-solid fa-globe lang-icon"></i>
            <ul class="lang-menu">
                <li onclick="changeLanguage('fr')">🇨🇵 Français</li>
                <li onclick="changeLanguage('en')">🇺🇲 English</li>
                <li onclick="changeLanguage('de')">🇩🇪 Deutsch</li>
                <li onclick="changeLanguage('es')">🇪🇦 Español</li>
                <li onclick="changeLanguage('tr')">🇹🇷 Türkçe</li>
                <li onclick="changeLanguage('cs')">🇨🇿 Čeština</li>
            </ul>
        </div>
        
        <div id="google_translate_element"></div>

        <div class="logo-container">
            <img src="image/logo.png" alt="Logo">
        </div>
        
        <?php echo $message; ?>
        
        <form method="POST">
            <div class="input-group"><i class="fa-solid fa-envelope"></i><input type="email" name="email" placeholder="E-mail" required></div>
            <div class="input-group"><i class="fa-solid fa-lock"></i><input type="password" name="password" placeholder="Mot de passe" required></div>
            <a href="pass.php"><div class="forgot">Mot de passe oublié ?</div></a>
            <button type="submit">Connexion</button>
            <button type="button" class="btn-register" onclick="window.location.href='inscription.php'">S'inscrire</button>
        </form>
    </div>

    <script type="text/javascript">
        function googleTranslateElementInit() {
            new google.translate.TranslateElement({pageLanguage: 'fr', autoDisplay: false}, 'google_translate_element');
        }

        function changeLanguage(lang) {
            var combo = document.querySelector('.goog-te-combo');
            if (combo) {
                combo.value = lang;
                combo.dispatchEvent(new Event('change'));
            }
            localStorage.setItem('userLanguage', lang);
        }

        // Nettoyage forcé des éléments Google
        setInterval(function() {
            document.body.style.top = "0px";
        }, 50);
    </script>
    <script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>
</body>
</html>