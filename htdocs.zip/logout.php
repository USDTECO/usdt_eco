<?php
session_start();

// 1. Détruire toutes les variables de session
$_SESSION = array();

// 2. Si un cookie de session est utilisé, le supprimer
if (ini_get("session.use_cookies")) {
    $params = session_get_cookie_params();
    setcookie(session_name(), '', time() - 42000,
        $params["path"], $params["domain"],
        $params["secure"], $params["httponly"]
    );
}

// 3. Détruire la session
session_destroy();

// 4. Rediriger vers la page de connexion (login.php)
header("Location: login.php");
exit();
?>
