<?php
session_start();
require_once 'db.php';

// SÉCURITÉ : Autoriser les 'admin' ET les 'moderateur'
$role = strtolower(trim($_SESSION['role'] ?? ''));
if (!isset($_SESSION['user_id']) || ($role !== 'admin' && $role !== 'moderateur')) {
    header("Location: index.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Espace Modérateur</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { font-family: sans-serif; background: #f0f2f5; padding: 20px; }
        .container { max-width: 600px; margin: auto; }
        .grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; }
        .card { background: white; padding: 25px; border-radius: 15px; text-align: center; box-shadow: 0 4px 6px rgba(0,0,0,0.1); text-decoration: none; color: #333; }
        .card i { font-size: 2rem; color: #1a237e; margin-bottom: 10px; }
    </style>
</head>
<body>
<div class="container">
    <h2>Panneau Modérateur</h2>
    <div class="grid">
        <a href="voir_kyc.php" class="card"><i class="fa-solid fa-id-card"></i><p>Voir KYC</p></a>
        <a href="admin_publier.php" class="card"><i class="fa-solid fa-bullhorn"></i><p>Publier Offre</p></a>
        <a href="generer_code.php" class="card"><i class="fa-solid fa-barcode"></i><p>Générer Codes</p></a>
        <a href="solder.php" class="card"><i class="fa-solid fa-wallet"></i><p>Solder Comptes</p></a>
    </div>
</div>
</body>
</html>
