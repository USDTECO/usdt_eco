<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$session_key = 'code_verified_' . $user_id;
$show_modal = !isset($_SESSION[$session_key]);

$message = "";
$error = "";

// 1. Traitement du code PIN
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['security_code'])) {
    $input_code = $_POST['security_code'];
    $stmt = $pdo->prepare("SELECT pin_code FROM utilisateurs WHERE id = ?");
    $stmt->execute([$user_id]);
    $user = $stmt->fetch();

    if (empty($user['pin_code'])) {
        $pdo->prepare("UPDATE utilisateurs SET pin_code = ? WHERE id = ?")
            ->execute([password_hash($input_code, PASSWORD_DEFAULT), $user_id]);
        $_SESSION[$session_key] = true;
        $show_modal = false;
    } elseif (password_verify($input_code, $user['pin_code'])) {
        $_SESSION[$session_key] = true;
        $show_modal = false;
    } else {
        $error = "Code PIN incorrect.";
    }
}

// 2. Traitement des mises à jour (uniquement si le PIN est validé)
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_SESSION[$session_key])) {
    if (isset($_POST['update_profile'])) {
        $stmt = $pdo->prepare("UPDATE utilisateurs SET nom_prenom = ?, email = ?, pays = ?, date_naissance = ? WHERE id = ?");
        $stmt->execute([$_POST['nom_prenom'], $_POST['email'], $_POST['pays'], $_POST['date_naissance'], $user_id]);
        $message = "Profil mis à jour avec succès.";
    }

    if (isset($_POST['update_password'])) {
        $stmt = $pdo->prepare("SELECT mot_de_passe FROM utilisateurs WHERE id = ?");
        $stmt->execute([$user_id]);
        $user = $stmt->fetch();

        if ($user && password_verify($_POST['old_password'], $user['mot_de_passe'])) {
            $hash_new = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
            $pdo->prepare("UPDATE utilisateurs SET mot_de_passe = ? WHERE id = ?")->execute([$hash_new, $user_id]);
            $message = "Mot de passe mis à jour avec succès.";
        } else {
            $error = "Ancien mot de passe incorrect.";
        }
    }
}

$stmt_user = $pdo->prepare("SELECT * FROM utilisateurs WHERE id = ?");
$stmt_user->execute([$user_id]);
$data = $stmt_user->fetch(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Paramètres</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family: sans-serif; }
        body { background: #f4f7f9; display: flex; justify-content: center; }
        .mobile { width: 390px; background: #fff; min-height: 100vh; padding: 20px; }
        
        /* Modal Sécurité */
        #security-modal { position: fixed; inset: 0; background: #fff; display: <?php echo $show_modal ? 'flex' : 'none'; ?>; justify-content: center; align-items: center; z-index: 9999; }
        .code-input { width: 50px; height: 50px; border: 2px solid #1e293b; border-radius: 8px; text-align: center; font-size: 1.5rem; margin: 0 5px; }

        .header { margin-bottom: 25px; }
        .section { margin-bottom: 30px; padding-bottom: 20px; border-bottom: 1px solid #eee; }
        .section h3 { font-size: 0.8rem; color: #666; margin-bottom: 15px; text-transform: uppercase; }
        label { font-size: 0.75rem; color: #888; margin-left: 5px; }
        input { width: 100%; padding: 12px; margin-bottom: 10px; border: 1px solid #ddd; border-radius: 8px; }
        button { width: 100%; padding: 12px; background: #1a237e; color: white; border: none; border-radius: 8px; font-weight: bold; cursor: pointer; }
        .msg { font-size: 0.8rem; color: #2e7d32; margin-bottom: 15px; text-align: center; font-weight: bold; }
        .err { font-size: 0.8rem; color: #d32f2f; margin-bottom: 15px; text-align: center; font-weight: bold; }
    </style>
</head>
<body>

<div id="security-modal">
    <form method="POST" id="code-form">
        <h3 style="text-align:center; margin-bottom:20px;">Code PIN requis</h3>
        <?php if($error): ?><div class="err"><?= $error ?></div><?php endif; ?>
        <input type="text" class="code-input" maxlength="1" inputmode="numeric" oninput="next(this)">
        <input type="text" class="code-input" maxlength="1" inputmode="numeric" oninput="next(this)">
        <input type="text" class="code-input" maxlength="1" inputmode="numeric" oninput="next(this)">
        <input type="text" class="code-input" maxlength="1" inputmode="numeric" oninput="next(this)">
        <input type="text" class="code-input" maxlength="1" inputmode="numeric" oninput="checkAuto(this)">
        <input type="hidden" name="security_code" id="hidden-code">
    </form>
</div>

<div class="mobile">
    <div class="header">
        <a href="compte.php" style="color:#000;"><i class="fa-solid fa-arrow-left"></i> Retour</a>
        <h2 style="margin-top:15px;">Paramètres</h2>
    </div>

    <?php if($message): ?><div class="msg"><?= $message ?></div><?php endif; ?>
    <?php if($error && !$show_modal): ?><div class="err"><?= $error ?></div><?php endif; ?>

    <form method="POST" class="section">
        <h3>Informations personnelles</h3>
        <input type="text" value="<?= htmlspecialchars($data['code_personnel']) ?>" disabled>
        <input type="text" name="nom_prenom" value="<?= htmlspecialchars($data['nom_prenom']) ?>" required>
        <input type="email" name="email" value="<?= htmlspecialchars($data['email']) ?>" required>
        <input type="text" name="pays" value="<?= htmlspecialchars($data['pays'] ?? '') ?>">
        <input type="date" name="date_naissance" value="<?= htmlspecialchars($data['date_naissance'] ?? '') ?>">
        <button type="submit" name="update_profile">Enregistrer</button>
    </form>

    <form method="POST" class="section">
        <h3>Changer le mot de passe</h3>
        <input type="password" name="old_password" placeholder="Ancien mot de passe" required>
        <input type="password" name="new_password" placeholder="Nouveau mot de passe" required>
        <button type="submit" name="update_password">Mettre à jour</button>
    </form>
</div>

<script>
function next(el) { if(el.value.length) el.nextElementSibling?.focus(); }
function checkAuto(el) {
    let inputs = document.querySelectorAll('.code-input');
    let code = Array.from(inputs).map(i => i.value).join('');
    if(code.length === 5) { document.getElementById('hidden-code').value = code; document.getElementById('code-form').submit(); }
}
</script>

<?php include 'traduction_script.php'; ?>

</body>
</html>