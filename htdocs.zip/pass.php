<?php
require_once 'db.php';
$message = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email = $_POST['email'];
    $new_pass = password_hash($_POST['new_password'], PASSWORD_DEFAULT);
    $stmt = $pdo->prepare("INSERT INTO demandes_changement_mdp (email, nouveau_pass_hash) VALUES (?, ?)");
    $stmt->execute([$email, $new_pass]);
    $message = "Demande envoyée. En attente de validation.";
}
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Récupération de compte</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { box-sizing: border-box; font-family: 'Segoe UI', sans-serif; }
        body { background: #f4f7f9; display: flex; justify-content: center; align-items: center; min-height: 100vh; margin: 0; }
        .mobile { width: 390px; background: #fff; padding: 30px; border-radius: 30px; box-shadow: 0 10px 25px rgba(0,0,0,0.05); text-align: center; }
        
        .icon-lock { font-size: 2.5rem; color: #1a237e; margin-bottom: 15px; }
        h2 { color: #1a237e; margin-bottom: 10px; font-size: 1.3rem; }
        p { color: #888; font-size: 0.85rem; margin-bottom: 20px; line-height: 1.4; }
        
        .input-group { position: relative; margin-bottom: 15px; }
        .input-group i { position: absolute; left: 15px; top: 15px; color: #aaa; }
        input { width: 100%; padding: 12px 12px 12px 40px; border: 1px solid #eee; border-radius: 12px; background: #f9f9f9; }
        
        button { width: 100%; padding: 12px; background: #1a237e; color: white; border: none; border-radius: 12px; font-weight: bold; cursor: pointer; margin-top: 5px; }
        .msg { background: #e8f5e9; color: #2e7d32; padding: 10px; border-radius: 8px; font-size: 0.8rem; margin-bottom: 15px; }
        
        /* Section Contact */
        .contact-box { margin-top: 25px; padding-top: 20px; border-top: 1px solid #eee; }
        .contact-text { font-size: 0.75rem; color: #666; margin-bottom: 15px; text-align: left; }
        .btn-contact { display: block; width: 100%; padding: 12px; background: #f4f7f9; color: #1a237e; border: 1px solid #1a237e; border-radius: 12px; text-decoration: none; font-weight: bold; font-size: 0.9rem; }
    </style>
</head>
<body>

<div class="mobile">
    <i class="fa-solid fa-shield-halved icon-lock"></i>
    <h2>Mot de passe oublié</h2>
    <p>Pour des raisons de sécurité, nous pouvons vous contacter avant le changement.</p>
    
    <?php if($message): ?><div class="msg"><?= $message ?></div><?php endif; ?>
    
    <form method="POST">
        <div class="input-group">
            <i class="fa-solid fa-envelope"></i>
            <input type="email" name="email" placeholder="Adresse e-mail" required>
        </div>
        <div class="input-group">
            <i class="fa-solid fa-lock"></i>
            <input type="password" name="new_password" placeholder="Nouveau mot de passe" required>
        </div>
        <button type="submit">Soumettre la demande</button>
    </form>

    <div class="contact-box">
        <p class="contact-text">
            Si nous ne mettons pas à jour votre mot de passe, contactez-nous pour connaître la raison.
        </p>
        <a href="mailto:finanzis.fr@gmail.com" class="btn-contact">
            <i class="fa-solid fa-envelope-open-text"></i> Contacter le support
        </a>
    </div>
</div>
<?php include 'traduction_script.php'; ?>

</body>
</html>