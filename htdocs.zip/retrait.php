<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$message = "";
$message_type = ""; 

// Récupération des infos utilisateur incluant le PIN
$stmt = $pdo->prepare("SELECT solde, pin_code FROM utilisateurs WHERE id = ?");
$stmt->execute([$user_id]);
$user = $stmt->fetch();
$solde = $user['solde'] ?? 0;

// CORRECTION : On vérifie la session liée à cet utilisateur précis
$session_key = 'code_verified_' . $user_id;
$show_modal = !isset($_SESSION[$session_key]);

// Traitement du code de sécurité
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['security_code'])) {
    $input_code = $_POST['security_code'];
    
    if (empty($user['pin_code'])) {
        $pdo->prepare("UPDATE utilisateurs SET pin_code = ? WHERE id = ?")
            ->execute([password_hash($input_code, PASSWORD_DEFAULT), $user_id]);
        $_SESSION[$session_key] = true;
        $show_modal = false;
    } else {
        if (password_verify($input_code, $user['pin_code'])) {
            $_SESSION[$session_key] = true;
            $show_modal = false;
        } else {
            $message = "Code incorrect !";
            $message_type = "error";
        }
    }
}

// Traitement du formulaire de retrait (Vérification de la session spécifique)
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['montant']) && isset($_SESSION[$session_key])) {
    $montant = floatval($_POST['montant']); 
    
    if ($montant < 500) {
        $message = "Votre fond est insuffisant !";
        $message_type = "error";
    } elseif ($solde < $montant) {
        $message = "Fonds insuffisants. Solde actuel : " . number_format($solde, 2) . "$";
        $message_type = "error";
    } else {
        $update = $pdo->prepare("UPDATE utilisateurs SET solde = solde - ? WHERE id = ?");
        $update->execute([$montant, $user_id]);
        
        $insert = $pdo->prepare("INSERT INTO transactions (user_id, type, montant) VALUES (?, 'retrait', ?)");
        $insert->execute([$user_id, $montant]);
        
        $message = "Opération réussie ! Retrait de " . number_format($montant, 2) . "$ en cours de traitement...";
        $message_type = "success";
        $solde -= $montant;
    }
}
?>


<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Retrait</title>
    <style>
        * { margin: 0; padding: 0; box-sizing: border-box; font-family: 'Inter', sans-serif; }
        body { background: #f8fafc; color: #1e293b; min-height: 100vh; display: flex; justify-content: center; }
        .app-container { width: 100%; max-width: 500px; background: #ffffff; min-height: 100vh; padding: 25px; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        .balance-box { background: #1e293b; color: #fff; padding: 25px; border-radius: 20px; margin-bottom: 25px; }
        .field { margin-bottom: 18px; }
        .field label { display: block; font-size: 0.8rem; font-weight: 600; margin-bottom: 6px; color: #475569; }
        .field input, .field select { width: 100%; padding: 12px; border: 1px solid #cbd5e1; border-radius: 10px; font-size: 0.95rem; }
        .btn-submit { width: 100%; padding: 14px; background: #1e293b; color: white; border: none; border-radius: 10px; font-size: 1rem; font-weight: 600; cursor: pointer; }
        
        .alert { padding: 15px; border-radius: 10px; margin-bottom: 20px; text-align: center; font-weight: bold; }
        .alert-success { background: #dcfce7; color: #166534; border: 1px solid #bbf7d0; }
        .alert-error { background: #fee2e2; color: #991b1b; border: 1px solid #fecaca; }

        #security-modal { position: fixed; top:0; left:0; width:100%; height:100%; background: #ffffff; z-index: 9999; display: <?php echo $show_modal ? 'flex' : 'none'; ?>; justify-content: center; align-items: center; }
        .code-box { display: flex; gap: 10px; }
        .code-input { width: 50px; height: 50px; border: 2px solid #1e293b; border-radius: 8px; text-align: center; font-size: 1.5rem; }
    </style>
</head>
<body>

<div id="security-modal">
    <form method="POST" id="code-form">
        <h3 style="text-align:center; margin-bottom:20px; color:#1e293b;">
            <?php echo empty($user['pin_code']) ? "Définir votre code PIN" : "Entrer votre code PIN"; ?>
        </h3>
        <div class="code-box">
            <input type="text" class="code-input" maxlength="1" inputmode="numeric" pattern="[0-9]*" oninput="next(this)">
            <input type="text" class="code-input" maxlength="1" inputmode="numeric" pattern="[0-9]*" oninput="next(this)">
            <input type="text" class="code-input" maxlength="1" inputmode="numeric" pattern="[0-9]*" oninput="next(this)">
            <input type="text" class="code-input" maxlength="1" inputmode="numeric" pattern="[0-9]*" oninput="next(this)">
            <input type="text" class="code-input" maxlength="1" inputmode="numeric" pattern="[0-9]*" oninput="checkAuto(this)">
        </div>
        <input type="hidden" name="security_code" id="hidden-code">
    </form>
</div>

<div class="app-container">
    <h2>Retirer des fonds</h2>
    <?php if($message): ?><div class="alert alert-<?= $message_type ?>"><?= $message ?></div><?php endif; ?>
    
    <div class="balance-box notranslate">
        <div style="font-size: 0.8rem; opacity: 0.8;">Solde du portefeuille</div>
        <div style="font-size: 1.8rem; font-weight: 700;">$<?= number_format($solde, 2) ?></div>
    </div>

    <form method="POST">
        <div class="field">
            <label>Méthode de retrait</label>
            <select name="method" id="method" onchange="updateFields()">
                <option value="bank">Virement Bancaire</option>
                <option value="usdt">USDT (TRC20)</option>
                <option value="btc">Bitcoin (BTC)</option>
            </select>
        </div>
        <div id="bank-fields">
            <div class="field"><label>Nom du bénéficiaire</label><input type="text" name="beneficiaire"></div>
            <div class="field"><label>IBAN</label><input type="text" name="iban"></div>
            <div class="field"><label>Code SWIFT/BIC</label><input type="text" name="swift"></div>
        </div>
        <div class="field" id="crypto-field" style="display:none;">
            <label id="crypto-label">Adresse</label>
            <input type="text" name="adresse">
        </div>
        <div class="field">
            <label>Montant du retrait </label>
            <input type="number" name="montant" step="0.01" inputmode="decimal" required>
        </div>
        <button type="submit" class="btn-submit">Confirmer le retrait</button>
    </form>
</div> 

<script>
function next(el) { if(el.value.length) el.nextElementSibling?.focus(); }
function checkAuto(el) {
    let inputs = document.querySelectorAll('.code-input');
    let code = "";
    inputs.forEach(i => code += i.value);
    if(code.length === 5) {
        document.getElementById('hidden-code').value = code;
        document.getElementById('code-form').submit();
    }
}
function updateFields() {
    const method = document.getElementById('method').value;
    document.getElementById('bank-fields').style.display = (method === 'bank') ? 'block' : 'none';
    document.getElementById('crypto-field').style.display = (method !== 'bank') ? 'block' : 'none';
    document.getElementById('crypto-label').innerText = (method === 'usdt') ? "Adresse USDT (TRC20)" : "Adresse Bitcoin (BTC)";
}
</script>

<?php include 'traduction_script.php'; ?>

</body>
</html>