<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

// Traitement AJAX pour les modifications de solde
if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['ajax'])) {
    $user_id = $_POST['user_id'];
    $montant = (float)$_POST['montant'];
    $type = $_POST['type']; 

    if ($type == 'ajouter') {
        // Ajoute le montant au solde actuel
        $stmt = $pdo->prepare("UPDATE utilisateurs SET solde = solde + ? WHERE id = ?");
        $stmt->execute([$montant, $user_id]);
        
        // --- MISE À JOUR : Enregistrement dans l'historique ---
        $insert = $pdo->prepare("INSERT INTO transactions (user_id, type, montant) VALUES (?, 'depot', ?)");
        $insert->execute([$user_id, $montant]);
        
    } else {
        // Remplace le solde actuel par le montant saisi (sans enregistrer dans l'historique car c'est une correction manuelle)
        $stmt = $pdo->prepare("UPDATE utilisateurs SET solde = ? WHERE id = ?");
        $stmt->execute([$montant, $user_id]);
    }
    
    // Récupérer le nouveau solde pour mise à jour visuelle
    $nouveau = $pdo->prepare("SELECT solde FROM utilisateurs WHERE id = ?");
    $nouveau->execute([$user_id]);
    echo number_format($nouveau->fetchColumn(), 2, '.', '');
    exit();
}

// Récupération de la liste des utilisateurs
$users = $pdo->query("SELECT id, nom_prenom, email, solde FROM utilisateurs")->fetchAll();
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestion des Dépôts</title>
    <style>
        body { font-family: sans-serif; padding: 20px; background: #eef2f5; }
        h1 { color: #1a237e; font-size: 20px; margin-bottom: 20px; }
        table { width: 100%; border-collapse: collapse; background: white; border-radius: 10px; overflow: hidden; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        th, td { padding: 15px; border-bottom: 1px solid #eee; text-align: left; }
        input { padding: 8px; width: 80px; border: 1px solid #ddd; border-radius: 5px; }
        button { padding: 8px 12px; border: none; border-radius: 5px; cursor: pointer; color: white; font-weight: bold; }
        .btn-add { background: #2e7d32; }
        .btn-edit { background: #1a237e; }
    </style>
</head>
<body>
    <h1>Administration : Gestion des soldes</h1>
    <table>
        <tr>
            <th>Utilisateur</th>
            <th>Solde Actuel</th>
            <th>Actions</th>
        </tr>
        <?php foreach ($users as $u): ?>
        <tr>
            <td>
                <strong><?php echo htmlspecialchars($u['nom_prenom']); ?></strong><br>
                <small style="color: #666;"><?php echo htmlspecialchars($u['email']); ?></small>
            </td>
            <td id="solde_<?php echo $u['id']; ?>">$ <?php echo number_format($u['solde'], 2); ?></td>
            <td>
                <input type="number" step="0.01" id="montant_<?php echo $u['id']; ?>" placeholder="Montant">
                <button class="btn-add" onclick="updateSolde(<?php echo $u['id']; ?>, 'ajouter')">+</button>
                <button class="btn-edit" onclick="updateSolde(<?php echo $u['id']; ?>, 'definir')">Modifier</button>
            </td>
        </tr>
        <?php endforeach; ?>
    </table>

    <script>
    function updateSolde(userId, type) {
        let montant = document.getElementById('montant_' + userId).value;
        if(montant === "") { alert("Veuillez entrer un montant"); return; }
        
        let formData = new FormData();
        formData.append('ajax', '1');
        formData.append('user_id', userId);
        formData.append('montant', montant);
        formData.append('type', type);

        fetch('', { method: 'POST', body: formData })
        .then(response => response.text())
        .then(data => {
            document.getElementById('solde_' + userId).innerText = '$ ' + data;
            document.getElementById('montant_' + userId).value = '';
        });
    }
    </script>
</body>
</html>
