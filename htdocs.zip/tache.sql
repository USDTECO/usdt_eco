-- phpMyAdmin SQL Dump
-- version 5.2.2
-- https://www.phpmyadmin.net/
--
-- Hôte : localhost
-- Généré le : dim. 07 juin 2026 à 17:36
-- Version du serveur : 5.7.34
-- Version de PHP : 8.2.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de données : `tache`
--

-- --------------------------------------------------------

--
-- Structure de la table `codes_invitation`
--

CREATE TABLE `codes_invitation` (
  `id` int(11) NOT NULL,
  `code` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `est_utilise` tinyint(1) DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `codes_invitation`
--

INSERT INTO `codes_invitation` (`id`, `code`, `est_utilise`) VALUES
(1, 'CCFC59C7', 0),
(2, 'CBE66BCC', 0),
(3, 'DD79A3AF', 0),
(4, 'C0A34831', 0),
(5, '5F7BCCDE', 0),
(6, '30FF1743', 0),
(7, '8CF618F5', 0),
(8, '62AC4C63', 0),
(9, '1670E0C3', 0),
(10, 'DBA4B82C', 1),
(11, '68BCD3DB', 1),
(12, '7EBFDD6B', 1),
(13, 'CD3B57F7', 1),
(14, 'AB8B38A4', 1),
(15, '6BD4BFA7', 0),
(16, '6DDFCF60', 0),
(17, '65DB5299', 0),
(18, 'E4D3F501', 0),
(19, 'D8501E10', 1);

-- --------------------------------------------------------

--
-- Structure de la table `demandes_changement_mdp`
--

CREATE TABLE `demandes_changement_mdp` (
  `id` int(11) NOT NULL,
  `email` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `nouveau_pass_hash` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_demande` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `demandes_changement_mdp`
--

INSERT INTO `demandes_changement_mdp` (`id`, `email`, `nouveau_pass_hash`, `date_demande`) VALUES
(2, 'issa1@gmail.com', '$2y$10$NEGrI.JAoaAcsd9Uk5gG/ulznNZ9CwOb8bbbeuFZdvXNCErN/nlWm', '2026-06-07 01:57:49');

-- --------------------------------------------------------

--
-- Structure de la table `publications`
--

CREATE TABLE `publications` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `titre` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `solde` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `profit` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_pub` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `disponible` tinyint(1) DEFAULT '1',
  `description` text COLLATE utf8mb4_unicode_ci
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `publications`
--

INSERT INTO `publications` (`id`, `user_id`, `titre`, `solde`, `profit`, `image_url`, `date_pub`, `disponible`, `description`) VALUES
(13, 6, 'Boursorama', '70', '17.50', 'uploads/1780741817_logo9_20_184135.png', '2026-06-06 10:30:17', 0, 'Prêt pour voyager en urgence '),
(18, 6, 'Boursorama', '60000', '15000.00', 'uploads/1780783984_logo12_18_1874.png', '2026-06-06 22:13:05', 1, 'eghh');

-- --------------------------------------------------------

--
-- Structure de la table `security_code`
--

CREATE TABLE `security_code` (
  `id` int(11) NOT NULL,
  `code` varchar(5) COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `security_code`
--

INSERT INTO `security_code` (`id`, `code`) VALUES
(1, '33333');

-- --------------------------------------------------------

--
-- Structure de la table `transactions`
--

CREATE TABLE `transactions` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `montant` decimal(10,2) NOT NULL,
  `date` datetime DEFAULT CURRENT_TIMESTAMP
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `transactions`
--

INSERT INTO `transactions` (`id`, `user_id`, `type`, `montant`, `date`) VALUES
(1, 6, 'depot', 25000.00, '2026-06-06 18:22:54'),
(2, 6, 'retrait', 500.00, '2026-06-06 18:24:06'),
(3, 6, 'retrait', 500.00, '2026-06-06 23:19:36'),
(4, 6, 'retrait', 500.00, '2026-06-06 23:19:54'),
(5, 6, 'retrait', 500.00, '2026-06-06 23:20:06'),
(6, 6, 'retrait', 500.00, '2026-06-06 23:20:17'),
(7, 6, 'retrait', 500.00, '2026-06-06 23:20:39'),
(8, 6, 'retrait', 500.00, '2026-06-06 23:20:51'),
(9, 6, 'retrait', 500.00, '2026-06-06 23:22:05'),
(10, 6, 'retrait', 500.00, '2026-06-06 23:22:11'),
(11, 6, 'retrait', 200.00, '2026-08-06 00:22:17'),
(12, 6, 'retrait', 500.00, '2026-06-07 11:50:20'),
(13, 6, 'retrait', 500.00, '2026-06-07 11:52:15'),
(14, 6, 'retrait', 500.00, '2026-06-07 11:59:13'),
(15, 6, 'retrait', 500.00, '2026-06-07 12:03:18'),
(16, 8, 'depot', 5000.00, '2026-06-07 16:06:45'),
(17, 8, 'retrait', 500.00, '2026-06-07 16:32:31');

-- --------------------------------------------------------

--
-- Structure de la table `transactions_en_attente`
--

CREATE TABLE `transactions_en_attente` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `pub_id` int(11) NOT NULL,
  `montant_bloque` decimal(10,2) NOT NULL,
  `date_creation` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `statut` int(11) DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `transactions_en_attente`
--

INSERT INTO `transactions_en_attente` (`id`, `user_id`, `pub_id`, `montant_bloque`, `date_creation`, `statut`) VALUES
(1, 6, 14, 68.75, '2026-06-06 22:09:18', 1),
(2, 6, 17, 62.50, '2026-06-06 22:14:21', 1),
(3, 6, 19, 125.00, '2026-06-06 22:16:19', 1),
(4, 6, 12, 7500.00, '2026-06-06 23:02:03', 1),
(5, 6, 20, 250.00, '2026-06-06 23:07:00', 1),
(6, 8, 21, 625.00, '2026-06-07 15:21:44', 1);

-- --------------------------------------------------------

--
-- Structure de la table `utilisateurs`
--

CREATE TABLE `utilisateurs` (
  `id` int(11) NOT NULL,
  `nom_prenom` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_naissance` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pays` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mot_de_passe` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code_invitation` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date_inscription` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `code_personnel` varchar(8) COLLATE utf8mb4_unicode_ci NOT NULL,
  `role` enum('user','admin','moderateur') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `piece_recto` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `piece_verso` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `solde` decimal(10,2) DEFAULT '0.00',
  `profit_total` decimal(10,2) DEFAULT '0.00',
  `recto_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `verso_path` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pin_code` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Déchargement des données de la table `utilisateurs`
--

INSERT INTO `utilisateurs` (`id`, `nom_prenom`, `email`, `date_naissance`, `pays`, `mot_de_passe`, `code_invitation`, `date_inscription`, `code_personnel`, `role`, `piece_recto`, `piece_verso`, `solde`, `profit_total`, `recto_path`, `verso_path`, `pin_code`) VALUES
(7, 'Jhon', 'admin1@issa.com', '23/08/2005', 'Suisse', '$2y$10$RnEf/JQKcvylRgc9r8Mqy.8XZakJDlt/AZmonArhRVtgMFssLyFqi', 'AB8B38A4', '2026-06-06 23:22:03', '76047579', 'admin', NULL, NULL, 0.00, 0.00, NULL, NULL, NULL);

--
-- Index pour les tables déchargées
--

--
-- Index pour la table `codes_invitation`
--
ALTER TABLE `codes_invitation`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `code` (`code`);

--
-- Index pour la table `demandes_changement_mdp`
--
ALTER TABLE `demandes_changement_mdp`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `publications`
--
ALTER TABLE `publications`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `security_code`
--
ALTER TABLE `security_code`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `transactions`
--
ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `transactions_en_attente`
--
ALTER TABLE `transactions_en_attente`
  ADD PRIMARY KEY (`id`);

--
-- Index pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `code_personnel` (`code_personnel`);

--
-- AUTO_INCREMENT pour les tables déchargées
--

--
-- AUTO_INCREMENT pour la table `codes_invitation`
--
ALTER TABLE `codes_invitation`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT pour la table `demandes_changement_mdp`
--
ALTER TABLE `demandes_changement_mdp`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT pour la table `publications`
--
ALTER TABLE `publications`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT pour la table `security_code`
--
ALTER TABLE `security_code`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT pour la table `transactions`
--
ALTER TABLE `transactions`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT pour la table `transactions_en_attente`
--
ALTER TABLE `transactions_en_attente`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT pour la table `utilisateurs`
--
ALTER TABLE `utilisateurs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
