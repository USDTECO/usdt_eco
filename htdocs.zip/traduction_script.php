<style>
    /* Masquage forcé du bandeau Google */
    html, body { top: 0 !important; position: relative !important; }
    .goog-te-banner-frame.skiptranslate, .goog-te-banner-frame, .goog-te-balloon-frame, 
    #goog-gt-tt, .goog-te-gadget-icon, .skiptranslate iframe {
        display: none !important; visibility: hidden !important;
    }
    #google_translate_element { display: none !important; }
</style>


<div id="google_translate_element" style="display:none;"></div>

<script type="text/javascript">
    function googleTranslateElementInit() {
        new google.translate.TranslateElement({
            pageLanguage: 'fr', 
            includedLanguages: 'fr,en,de,es,tr,cs',
            autoDisplay: false
        }, 'google_translate_element');
    }

    function changeLanguage(lang) {
        var combo = document.querySelector('.goog-te-combo');
        if (combo) {
            combo.value = lang;
            combo.dispatchEvent(new Event('change'));
            localStorage.setItem('userLanguage', lang);
        }
    }

    // Applique la langue dès que la page est chargée
    window.addEventListener('load', function() {
        var savedLang = localStorage.getItem('userLanguage');
        if (savedLang) {
            var checkReady = setInterval(function() {
                var combo = document.querySelector('.goog-te-combo');
                if (combo) {
                    changeLanguage(savedLang);
                    clearInterval(checkReady);
                }
            }, 200);
        }
    });

    // Nettoyage visuel constant
    setInterval(function() { document.body.style.top = "0px"; }, 50);
</script>
<script type="text/javascript" src="https://translate.google.com/translate_a/element.js?cb=googleTranslateElementInit"></script>