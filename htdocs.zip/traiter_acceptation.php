<?php
session_start();
require_once 'db.php';

if (!isset($_GET['id']) || !isset($_SESSION['user_id'])) {
    header("Location: activity.php");
    exit();
}

$pub_id = $_GET['id'];
$user_id = $_SESSION['user_id'];

// 1. Récupérer les données de l'offre
$stmt = $pdo->prepare("SELECT solde as montant_offre, profit FROM publications WHERE id = ?");
$stmt->execute([$pub_id]);
$pub = $stmt->fetch();

// 2. Récupérer le solde actuel de l'utilisateur
$stmtU = $pdo->prepare("SELECT solde FROM utilisateurs WHERE id = ?");
$stmtU->execute([$user_id]);
$user = $stmtU->fetch();

if ($pub && $user) {
    if ($user['solde'] >= $pub['montant_offre']) {
        try {
            $pdo->beginTransaction();

            // A. Déduire la mise du solde disponible
            $update_user = $pdo->prepare("UPDATE utilisateurs SET solde = solde - ? WHERE id = ?");
            $update_user->execute([$pub['montant_offre'], $user_id]);

            // B. Ajouter le profit total cumulé dans la table utilisateurs
            $update_profit = $pdo->prepare("UPDATE utilisateurs SET profit_total = profit_total + ? WHERE id = ?");
            $update_profit->execute([$pub['profit'], $user_id]);

            // C. Insérer le montant total (mise + profit) dans les transactions en attente
            $total_attente = $pub['montant_offre'] + $pub['profit'];
            $insert = $pdo->prepare("INSERT INTO transactions_en_attente (user_id, pub_id, montant_bloque, statut) VALUES (?, ?, ?, 1)");
            $insert->execute([$user_id, $pub_id, $total_attente]);

            // D. Supprimer la publication
            $pdo->prepare("DELETE FROM publications WHERE id = ?")->execute([$pub_id]);

            $pdo->commit();
            header("Location: activity.php");
            exit();
        } catch (Exception $e) {
            $pdo->rollBack();
            die("Erreur technique : " . $e->getMessage());
        }
    } else {
        header("Location: activity.php?error=insufficient");
        exit();
    }
} else {
    header("Location: activity.php");
    exit();
}
?>
