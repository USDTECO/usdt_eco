<?php
require_once 'db.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $user_id = $_POST['user_id'];
    $upload_dir = 'uploads/';
    
    $recto = $upload_dir . time() . '_recto.jpg';
    $verso = $upload_dir . time() . '_verso.jpg';
    
    if (move_uploaded_file($_FILES['recto']['tmp_name'], $recto) && 
        move_uploaded_file($_FILES['verso']['tmp_name'], $verso)) {
        
        $stmt = $pdo->prepare("UPDATE utilisateurs SET piece_recto = ?, piece_verso = ?, statut_verification = 'en_attente' WHERE id = ?");
        $stmt->execute([$recto, $verso, $user_id]);
        
        header("Location: login.php?success=1");
    }
}
?>
