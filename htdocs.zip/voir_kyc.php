<?php
session_start();
require_once 'db.php';

// Action de suppression côté Admin
if (isset($_POST['supprimer_admin'])) {
    $userId = $_POST['user_id'];
    
    // Récupérer les noms de fichiers pour les supprimer physiquement
    $stmt = $pdo->prepare("SELECT recto_path, verso_path FROM utilisateurs WHERE id = ?");
    $stmt->execute([$userId]);
    $files = $stmt->fetch();
    
    if ($files) {
        if (file_exists('uploads/' . $files['recto_path'])) unlink('uploads/' . $files['recto_path']);
        if (file_exists('uploads/' . $files['verso_path'])) unlink('uploads/' . $files['verso_path']);
    }

    // Réinitialiser les colonnes dans la BDD
    $stmt = $pdo->prepare("UPDATE utilisateurs SET recto_path = NULL, verso_path = NULL WHERE id = ?");
    $stmt->execute([$userId]);
    
    header("Location: voir_kyc.php");
    exit();
}

// Récupération des utilisateurs
$stmt = $pdo->query("SELECT id, nom_prenom, email, recto_path, verso_path FROM utilisateurs WHERE recto_path IS NOT NULL");
$users = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>Administration KYC</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        body { background: #f4f7f9; font-family: sans-serif; padding: 10px; }
        .admin-card { background: #fff; padding: 15px; border-radius: 12px; margin-bottom: 15px; box-shadow: 0 2px 5px rgba(0,0,0,0.1); }
        .user-info { font-weight: bold; margin-bottom: 10px; color: #1a237e; }
        .doc-preview { display: flex; gap: 10px; margin-bottom: 15px; }
        .doc-preview img { width: 50%; border-radius: 8px; border: 1px solid #ddd; }
        .actions { display: flex; gap: 10px; }
        .btn { padding: 10px; border: none; border-radius: 6px; cursor: pointer; flex: 1; font-weight: bold; }
        .btn-valider { background: #2e7d32; color: white; }
        .btn-supprimer { background: #c62828; color: white; }
    </style>
</head>
<body>

<h2><i class="fa-solid fa-shield-halved"></i> Soumissions KYC</h2>

<?php foreach ($users as $user): ?>
    <div class="admin-card">
        <div class="user-info"><?= htmlspecialchars($user['nom_prenom']) ?></div>
        <div class="doc-preview">
            <img src="uploads/<?= htmlspecialchars($user['recto_path']) ?>" alt="Recto">
            <img src="uploads/<?= htmlspecialchars($user['verso_path']) ?>" alt="Verso">
        </div>
        
        <form method="POST" class="actions">
            <input type="hidden" name="user_id" value="<?= $user['id'] ?>">
            <button type="button" class="btn btn-valider">Valider</button>
            <button type="submit" name="supprimer_admin" class="btn btn-supprimer" 
                    onclick="return confirm('Supprimer ces documents ?')">
                <i class="fa-solid fa-trash"></i> Supprimer
            </button>
        </form>
    </div>
<?php endforeach; ?>

</body>
</html>