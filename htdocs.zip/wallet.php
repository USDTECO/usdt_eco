<?php
session_start();
require_once 'db.php';

if (!isset($_SESSION['user_id'])) {
    header("Location: login.php");
    exit();
}

$user_id = $_SESSION['user_id'];
$stmt = $pdo->prepare("SELECT solde FROM utilisateurs WHERE id = ?");
$stmt->execute([$user_id]);
$u = $stmt->fetch();
$solde_courant = $u['solde'] ?? 0;

$stmt_attente = $pdo->prepare("SELECT SUM(montant_bloque) as total FROM transactions_en_attente WHERE user_id = ? AND statut = 1");
$stmt_attente->execute([$user_id]);
$a = $stmt_attente->fetch();
$total_en_attente = $a['total'] ?? 0;

$btc_addr = "bc1qarwcrfnuwl37gf78hjtrwkaeztgc5hj3d7eq6p";
$usdt_addr = "TMbVzWoHBV13bE5ZWFm4mUAcKXPGUBCroF";
?>
<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.5.1/css/all.min.css">
    <style>
        * { margin:0; padding:0; box-sizing:border-box; font-family: sans-serif; }
        body { background: #f8f9fa; display: flex; justify-content: center; min-height: 100vh; }
        .mobile { width: 390px; min-height: 100vh; background: #ffffff; padding: 20px; position: relative; box-shadow: 0 0 20px rgba(0,0,0,0.05); }
        .top-bar { display: flex; align-items: center; margin-bottom: 30px; }
        .back-btn { font-size: 1.2rem; color: #000; margin-right: 15px; cursor: pointer; }
        h2 { font-size: 1.4rem; color: #000; }
        
        .wallet-card { background: #ffffff; border: 1px solid #e0e0e0; padding: 30px; border-radius: 20px; box-shadow: 0 4px 15px rgba(0,0,0,0.05); margin-bottom: 25px; }
        .solde-container { text-align: left; margin-bottom: 30px; }
        .label { font-size: 0.9rem; color: #666; margin-bottom: 5px; }
        .value { font-size: 2.2rem; font-weight: bold; color: #2e7d32; }
        
        .footer-card { border-top: 1px solid #eee; padding-top: 20px; text-align: center; opacity: 0.6; filter: grayscale(1); }
        .attente-label { font-size: 0.8rem; text-transform: uppercase; letter-spacing: 1px; color: #555; font-weight: bold; }
        .attente-value { font-size: 1.5rem; font-weight: bold; margin-top: 5px; color: #333; }
        
        .btn-group { display: flex; gap: 15px; margin-bottom: 15px; }
        .btn { flex: 1; padding: 15px; border-radius: 15px; border: 1px solid #000; font-weight: bold; cursor: pointer; display: flex; align-items: center; justify-content: center; gap: 8px; text-decoration: none; transition: 0.3s; }
        .btn-depot { background: #000; color: #fff; } 
        .btn-retrait { background: #fff; color: #000; }
        .btn-historique { background: #fff; color: #000; width: 100%; padding: 15px; border-radius: 15px; text-align: center; display: block; text-decoration: none; font-weight: bold; border: 1px solid #000; margin-top: 15px; }
        
        /* Modal & Toast Design */
        .modal { display: none; position: fixed; top: 0; left: 0; width: 100%; height: 100%; background: rgba(0,0,0,0.7); z-index: 1000; justify-content: center; align-items: flex-end; }
        .modal-content { background: white; width: 100%; max-width: 390px; padding: 25px; border-radius: 30px 30px 0 0; animation: slideUp 0.3s; }
        @keyframes slideUp { from { transform: translateY(100%); } to { transform: translateY(0); } }
        
        .method-item { display: flex; align-items: center; padding: 15px; border: 1px solid #eee; border-radius: 15px; margin-bottom: 10px; cursor: pointer; transition: 0.2s; }
        .method-item:hover { background: #f9f9f9; }
        .method-item i { font-size: 1.5rem; margin-right: 15px; width: 30px; text-align: center; }
        .inactive { opacity: 0.4; pointer-events: none; }
        
        #address-view, #success-view { display: none; text-align: center; }
        .addr-box { background: #eee; padding: 15px; border-radius: 10px; margin: 15px 0; font-family: monospace; font-size: 0.85rem; display: flex; justify-content: space-between; align-items: center; }
        .confirm-btn { width: 100%; padding: 18px; background: #000; color: #fff; border: none; border-radius: 15px; font-weight: bold; margin-top: 10px; }
        
        /* Toast Style */
        #toast { visibility: hidden; min-width: 250px; background: #333; color: #fff; text-align: center; border-radius: 10px; padding: 16px; position: fixed; z-index: 1001; top: 30px; left: 50%; transform: translateX(-50%); }
        #toast.show { visibility: visible; animation: fadein 0.5s; }
        @keyframes fadein { from {top: 0; opacity: 0;} to {top: 30px; opacity: 1;} }
    </style>
</head>
<body>
<div id="toast"></div>
<div class="mobile">
    <div class="top-bar">
        <div class="back-btn" onclick="history.back()"><i class="fa-solid fa-arrow-left"></i></div>
        <h2>Mon Portefeuille</h2>
    </div>

    <div class="wallet-card notranslate"> 
        <div class="solde-container">
            <div class="label">Solde Disponible</div>
            <div class="value">$<?= number_format($solde_courant, 2) ?></div>
        </div>
        <div class="footer-card">
            <div class="attente-label"><i class="fa-solid fa-history"></i> Total en attente</div>
            <div class="attente-value">+<?= number_format($total_en_attente, 2) ?>$...</div>  
        </div>
     </div>

    <div class="btn-group">
        <button class="btn btn-depot" onclick="document.getElementById('modal').style.display='flex'"><i class="fa-solid fa-plus-circle"></i> Dépôt</button>
        <a href="retrait.php" class="btn btn-retrait"><i class="fa-solid fa-minus-circle"></i> Retrait</a>
    </div>
    <a href="historique.php" class="btn-historique"><i class="fa-solid fa-history"></i> Historique</a>  

    <div style="text-align: center; margin-top: 30px; color: #ccc; font-size: 6rem;">  
        <i class="fa-solid fa-wallet"></i>
    </div>
</div>


<div id="modal" class="modal" onclick="if(event.target==this) this.style.display='none'">
    <div class="modal-content">
        <div id="selection-view">
            <h3 style="margin-bottom:20px;">Choisir une méthode</h3>

          
 <div class="method-item inactive"><i class="fa-solid fa-credit-card"></i> <span>Carte Bancaire</span></div>
       
            <div class="method-item" onclick="selectMethod('Bitcoin', '<?= $btc_addr ?>')">
                <i class="fa-brands fa-bitcoin"></i> <span>Bitcoin (BTC)</span>
            </div>
            <div class="method-item" onclick="selectMethod('USDT', '<?= $usdt_addr ?>')">
                <i class="fa-solid fa-money-bill-transfer"></i> <span>USDT (TRC20)</span>
            </div>
 
 </div>

        <div id="address-view">
            <h3 id="method-title"></h3>
            <div class="addr-box">
                <span id="addr-text"></span>
                <i class="fa-solid fa-copy" onclick="copyAddr()" style="cursor:pointer;"></i>
            </div>
            <button class="confirm-btn" onclick="showSuccess()">Confirmer le paiement</button>
            <p style="margin-top:15px; font-size:0.8rem; color:#666; cursor:pointer;" onclick="backToSelection()">← Retour</p>
        </div>

        <div id="success-view">
            <i class="fa-solid fa-circle-check" style="font-size:50px; color:#2e7d32;"></i>
            <h3 style="margin:20px 0;">Opération en cours</h3>
            <p style="color:#555;">Votre compte sera crédité dès que nous recevons votre paiement.</p>
            <button class="confirm-btn" onclick="location.reload()">Terminer</button>
        </div>
    </div>
</div>

<script>
    function showToast(msg) {
        let x = document.getElementById("toast");
        x.innerText = msg;
        x.className = "show";
        setTimeout(function(){ x.className = x.className.replace("show", ""); }, 3000);
    }
    function selectMethod(name, addr) {
        document.getElementById('selection-view').style.display = 'none';
        document.getElementById('address-view').style.display = 'block';
        document.getElementById('method-title').innerText = name;
        document.getElementById('addr-text').innerText = addr;
    }
    function backToSelection() {
        document.getElementById('selection-view').style.display = 'block';
        document.getElementById('address-view').style.display = 'none';
    }
    function showSuccess() {
        document.getElementById('address-view').style.display = 'none';
        document.getElementById('success-view').style.display = 'block';
    }
    function copyAddr() {
        navigator.clipboard.writeText(document.getElementById('addr-text').innerText);
        showToast("Adresse copiée dans le presse-papier !");
    }
</script>

<?php include 'traduction_script.php'; ?>

</body>
</html>